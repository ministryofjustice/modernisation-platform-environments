#This lambda has been created to handle notification to slack channel on EdrmsDocumentException

import os
import base64
import gzip
import json
import logging
import boto3
from botocore.exceptions import ClientError
from dataclasses import dataclass
from typing import Optional

logs_client = boto3.client('logs')
sns_client = boto3.client('sns')    

logger = logging.getLogger()
logger.setLevel(logging.INFO)

@dataclass
class Config:
    """Configuration settings for the Lambda function."""    
    SNS_TOPIC_ARN = Optional[str]
    LOG_GROUP_NAME = Optional[str]

    @classmethod
    def from_env(cls) -> "Config":
        """Create configuration from environment variables."""
        return cls(
            SNS_TOPIC_ARN=os.getenv("SNS_TOPIC_ARN"),
            LOG_GROUP_NAME=os.getenv("LOG_GROUP_NAME")
        )
def lambda_handler(event, context):
    """Lambda function to monitor EdrmsDocumentException logs and send notifications."""
    try:
        config = Config.from_env()
        if not config.SNS_TOPIC_ARN:
            raise ValueError("SNS_TOPIC_ARN environment variable is not set.")
        if not config.LOG_GROUP_NAME:
            raise ValueError("LOG_GROUP_NAME environment variable is not set.")
        
        # Decode and decompress the log data
        compressed_payload = base64.b64decode(event['awslogs']['data'])
        payload = gzip.decompress(compressed_payload)
        log_data = json.loads(payload)

        log_stream_name = log_data['logStream']
        for log_event in log_data['logEvents']:
            message = log_event['message']
            timestamp = log_event['timestamp']
            
            logger.info(f"Log Stream: {log_stream_name}, Timestamp: {timestamp}, Message: {message}")
            response = logs_client.get_log_events(
                logGroupName=config.LOG_GROUP_NAME,
                logStreamName=log_stream_name,
                startTime=timestamp,
                limit=5
            )

            log_lines = [e['message'] for e in response['events']]
            sns_client.publish(
                TopicArn=config.SNS_TOPIC_ARN,
                Message='\n'.join(log_lines),
                Subject='EdrmsDocumentException Alert'
            )
    except Exception as e:
        logger.error(f"Error processing logs: {str(e)}")
        raise
