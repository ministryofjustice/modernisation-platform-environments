"""For modules related to installing packages.
"""
