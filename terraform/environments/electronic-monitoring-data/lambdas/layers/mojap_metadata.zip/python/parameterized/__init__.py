from .parameterized import parameterized, param, parameterized_class

__version__ = "0.7.5"
