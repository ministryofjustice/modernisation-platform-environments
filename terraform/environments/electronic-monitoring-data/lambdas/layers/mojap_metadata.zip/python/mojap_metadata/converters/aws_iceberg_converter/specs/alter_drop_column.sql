ALTER TABLE {{ database_name }}.{{ table_name }} DROP COLUMN {{ column_name }}
