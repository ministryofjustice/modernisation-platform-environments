import awswrangler as wr
from mojap_metadata.converters.sqlalchemy_converter import SQLAlchemyConverter
from sqlalchemy import create_engine, inspect


def get_rds_connection():
    con_sqlserver = wr.sqlserver.connect(
        secret_id="testing-glue-conn",
        odbc_driver_version=17,
    )
    return con_sqlserver


def handler(event, context):
    conn = get_rds_connection()
    engine = create_engine("mssql+pyodbc://", creator=lambda: conn)
    print(inspect(engine).get_pk_constraint("table1", "dbo"))
    sqlc = SQLAlchemyConverter(engine)
    metadata = sqlc.generate_to_meta_list(schema="dbo")
    print(metadata)
    return "done"
