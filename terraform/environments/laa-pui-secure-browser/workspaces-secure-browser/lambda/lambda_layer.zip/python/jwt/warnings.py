class RemovedInPyjwt3Warning(DeprecationWarning):
    pass
