import logging
import os
import json
import boto3
import pycurl
from botocore.exceptions import ClientError
from mypy_boto3_secretsmanager import SecretsManagerClient
import requests
from config.database_config import get_database_environment_settings
from datalayer.excel_manager import process_file
from datalayer.s3_manager import PaymentS3Bucket
from businesslayer.provider_acount_check_manager import provider_account_check
from businesslayer.payment_load_manager import process_payment_load
from validation.validate import validate_request
from typing import Any, Dict, Optional, Union, cast
from dataclasses import dataclass


logger = logging.getLogger(__name__)

class NotificationService:
    """Service for sending notifications to Slack."""

    def __init__(self, webhook_url: str, function_name: str = "ebs payment load notification"):
        if not webhook_url:
            raise ValueError("Slack webhook URL is required for notifications")

        self.webhook_url = webhook_url
        self.function_name = function_name
        logger.info("Slack notifications configured")

    def send_notification(
        self, title: str, message: str, is_error: bool = False
    ) -> bool:
        """Send a notification to Slack using the webhook."""
        curl = pycurl.Curl()

        try:
            # Prepare the Slack message with formatting
            emoji = ":broken_heart:" if is_error else ":white_check_mark:"
            color = "danger" if is_error else "good"

            payload = {
                "attachments": [
                    {
                        "color": color,
                        "title": f"{emoji} [{self.function_name}] {title}",
                        "text": message,
                        "footer": "ebs payment load notification",
                        "ts": int(time.time()),
                    }
                ]
            }

            # Convert payload to JSON
            json_payload = json.dumps(payload)

            # Configure curl for HTTP POST with JSON
            curl.setopt(pycurl.URL, self.webhook_url)
            curl.setopt(pycurl.POST, 1)
            curl.setopt(pycurl.POSTFIELDS, json_payload)
            curl.setopt(pycurl.HTTPHEADER, ["Content-Type: application/json"])
            curl.setopt(pycurl.TIMEOUT, 10)

            # Buffer for response (though Slack webhook responses are minimal)
            response_buffer = io.BytesIO()
            curl.setopt(pycurl.WRITEDATA, response_buffer)

            # Send the notification
            curl.perform()

            # Check HTTP status code
            http_code = curl.getinfo(pycurl.RESPONSE_CODE)
            if http_code >= 400:
                raise Exception(f"HTTP error {http_code}")

            logger.info(f"Slack notification sent successfully: {title}")
            return True

        except Exception as e:
            logger.error(f"Failed to send Slack notification: {e}")
            return False
        finally:
            curl.close()

class SecretsManager:
    """Manager for retrieving configuration from AWS Secrets Manager."""

    def __init__(self):
        self.client = cast(SecretsManagerClient, boto3.client("secretsmanager"))
        logger.info("Initialized Secrets Manager client")

    def get_credentials(self, secret_name: str) -> Dict[str, Union[str, int, bool]]:
        """Retrieve and parse credentials from Secrets Manager."""
        try:
            logger.info(f"Retrieving secret: {secret_name}")
            response = self.client.get_secret_value(SecretId=secret_name)

            # Parse the secret string
            secret_data = json.loads(response["SecretString"])
            logger.info(
                f"Successfully retrieved credentials with {len(secret_data)} keys"
            )

            return secret_data

        except ClientError as e:
            error_code = e.response["Error"]["Code"]
            error_msg = f"Failed to retrieve secret {secret_name}: {error_code}"
            logger.error(error_msg)
            raise Exception(error_msg)
        except json.JSONDecodeError as e:
            error_msg = f"Failed to parse secret JSON: {e}"
            logger.error(error_msg)
            raise Exception(error_msg)

@dataclass
class ValidateConfig:
    """Configuration with validation."""

    # Mandatory fields (no default values)
    slack_channel_webhook: str

    def __post_init__(self):
        """Validate configuration after initialization."""
        # Validate using the ConfigValidator
        config_dict = {
            "slack_channel_webhook": self.slack_channel_webhook,
        }

        ConfigValidator.validate_mandatory_fields(config_dict, "configuration")

        logger.info(f"Configuration validated")


class ConfigValidator:
    """Validator class for configuration validation."""

    @staticmethod
    def validate_mandatory_fields(config_dict: Dict[str, Any], field_name: str) -> None:
        """Validate that all mandatory fields are present and non-empty."""
        # Always mandatory fields
        mandatory_fields = {
            "slack_channel_webhook": config_dict.get("slack_channel_webhook")
        }
        missing_fields = [name for name, value in mandatory_fields.items() if not value]
        if missing_fields:
            raise ValueError(
                f"Missing required {field_name} fields: {', '.join(missing_fields)}"
            )
    @staticmethod
    def get_mandatory_secret(secrets_data: Dict, key: str) -> str:
        """Extract and validate a mandatory field from secrets."""
        value = secrets_data.get(key)
        if not value or not isinstance(value, str):
            raise ValueError(
                f"{key} must be a non-empty string in secrets, got: {value}"
            )
        return value

    @staticmethod
    def get_optional_secret(secrets_data: Dict, key: str) -> Optional[str]:
        """Extract and validate an optional field from secrets."""
        value = secrets_data.get(key)
        if value is not None and not isinstance(value, str):
            raise ValueError(
                f"{key} must be a string in secrets, got: {type(value).__name__}"
            )
        return value if value else None

     
    @staticmethod
    def get_mandatory_env(env_data: Dict, key: str) -> str:
        """Extract and validate a mandatory field from environment."""
        value = env_data.get(key)
        if not value:
            raise ValueError(f"{key} environment variable is required")
        return value
    
@dataclass
class Config:
    """Configuration settings for the Lambda function."""    
    SNS_TOPIC_ARN: Optional[str] = None
    LOG_GROUP_NAME: Optional[str] = None

    @classmethod
    def from_env(cls) -> "Config":
        """Create configuration from environment variables."""
        return cls(
            SNS_TOPIC_ARN=os.getenv("SNS_TOPIC_ARN"),
            LOG_GROUP_NAME=os.getenv("LOG_GROUP_NAME")
        )

def parse_config_from_env_and_secrets(
    env_data: Dict[str, Optional[str]], secrets_data: Dict[str, Union[str, int, bool]]
) -> ValidateConfig:
    """
    Parse configuration from both environment variables and secrets data.

    This function combines non-sensitive configuration from environment variables
    with sensitive credentials from AWS Secrets Manager.
    """


    # Create config object with properly separated concerns
    config = ValidateConfig(
        # Connection settings from mixed sources
        slack_channel_webhook=ConfigValidator.get_mandatory_secret(secrets_data, "slack_channel_webhook"),
        SNS_TOPIC_ARN=ConfigValidator.get_mandatory_env(env_data, "SNS_TOPIC_ARN"),
        LOG_GROUP_NAME=ConfigValidator.get_mandatory_env(env_data, "LOG_GROUP_NAME"),

    )

    return config


def make_json_friendly_response(response):
    """
    We hold a lot of response data in Pydantic BaseModel objects but these are not
    conveniently JSON serialisable and AWS needs a response that json.dumps()
    can digest. This function converts the BaseModel objects within the response
    into standard Python dictionaries, which do have JSON compatibility that AWS needs.
    """
    if response["excel_files"] is not None:
        response["excel_files"] = [e.dict() for e in response["excel_files"]]

    if response["validation_response"] is not None:
        response["validation_response"] = response["validation_response"].dict()

    if response["upload_file_result"] is not None:
        # We've three nested BaseModels here: upload_file_result, payment_load_result, failed_payment_details (in list)
        # The .dict() method is recursive, so covers all in one go.
        response["upload_file_result"] = response["upload_file_result"].dict()
    return response




# For convenient AWS running, this function needs to be called lambda_handler
def lambda_handler(event, context):
    """Upload monthly payment load spreadsheet"""
    environment_settings = get_database_environment_settings()
    # Get secret name from environment or event
    secret_name = os.environ.get("SECRET_NAME_WEBHOOK", event.get("secret_name_webhook"))
    if not secret_name:
        raise ValueError("SECRET_NAME not found in environment or event")
    if not isinstance(secret_name, str):
        raise ValueError(
            f"SECRET_NAME must be a string, got: {type(secret_name).__name__}"
        )

    # Retrieve sensitive credentials from Secrets Manager
    logger.info("Retrieving credentials from AWS Secrets Manager")
    secrets_manager = SecretsManager()
    secrets_data = secrets_manager.get_credentials(secret_name)

    # Validate that required credentials are present
    # Always require USER, HOST, and SLACK_WEBHOOK
    required_secrets = ["slack_channel_webhook"]
    missing_secrets = [key for key in required_secrets if key not in secrets_data]
    if missing_secrets:
        raise ValueError(f"Missing required secrets: {', '.join(missing_secrets)}")

    # Parse combined configuration
    logger.info("Parsing configuration from environment and secrets")
    config = parse_config_from_env_and_secrets(env_config, secrets_data)

    # Initialize services
    notification_service = NotificationService(
        config.slack_channel_webhook, context.function_name
    )

    response = {"excel_files": None,
                "validation_response": None,
                "upload_file_result": None,
                "file_errors": [],
                "success": False}

    logging.info("start_upload_file")
    filebucket = PaymentS3Bucket(environment_settings.s3_bucket_name)
    response["excel_files"] = filebucket.list_pending_excel_files()

    if len(response["excel_files"]) != 1:
        error_message = f"Must have a single .xlsx file. Found: {response['excel_files']}"
        logging.error(f"upload_file_error: {error_message}")
        response["file_errors"].append(error_message)
    else:
        filename = response["excel_files"][0].filename
        if filename in filebucket.list_processed_filenames():
            error_message = f"Filename {filename} already present in 'completed' folder"
            logging.error(f"upload_file_error: {error_message}")
            response["file_errors"].append(error_message)
        response["validation_response"] = validate_request(response["excel_files"][0])
        if response["validation_response"].status_code != 200:
            error_message = f"upload_file_validation_error: {response['validation_response']}"
            logging.error(error_message)

    if not response["file_errors"] and response["validation_response"].status_code == 200:
        file_content = filebucket.get_file_content(filename)
        payment_load_data = process_file(file_content, name=filename)
        provider_check_result = provider_account_check(payment_load_data)
        response["upload_file_result"] = process_payment_load(payment_load_data, provider_check_result)
        if response["upload_file_result"].payment_load_result.failed_payment_count == 0:
            filebucket.move_file_to_processed(filename)
            msg = (f"Payment Load Success: {filename}\n"
                   f"Payments loaded: {response['upload_file_result'].payment_load_result.committed_payment_count}")
            logging.info(f"finish_upload_file: {filename}, Number of payments loaded:" +
                         str(response.get("upload_file_result").payment_load_result.committed_payment_count))
            response["success"] = True
            is_error = False
        else:
            filebucket.move_file_to_failed(filename)
            msg = (f"Payment Load Error: {filename}\n"
                   f"Failed payments: {response['upload_file_result'].payment_load_result.failed_payment_count}")
            logging.error(f"upload_file_error: {filename} Failed payments: " +
                          str(response["upload_file_result"].payment_load_result.failed_payment_count))
            is_error = True
            
    notification_service.send_notification(
                        "EDRMS Document Exception",
                        msg, is_error
                    )

    return make_json_friendly_response(response)



