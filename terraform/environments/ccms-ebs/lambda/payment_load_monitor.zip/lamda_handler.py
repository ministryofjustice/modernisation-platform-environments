import json
import os
from typing import Any, Dict, Optional

import boto3

SNS_TOPIC_ARN: str = os.getenv("SNS_TOPIC_ARN", "")


def lambda_handler(event: Dict[str, Any], context: Optional[Any]) -> None:
    log_events = event.get("awslogs", {}).get("data", "")

    if not log_events:
        print("No log events found")
        return

    decoded_logs = json.loads(log_events)
    decoded_logs = json.loads(decoded_logs["logEvents"])

    sns_client = boto3.client("sns")

    for log_event in decoded_logs:
        message = json.loads(log_event["message"])

        # Filter based on level or message content
        # if message.get(
        #     "level"
        # ) == "INFO" and "start_excel_reader_read_file" in message.get("message", ""):
        #     send_to_slack_via_sns(message, sns_client)
        send_to_slack_via_sns(message, sns_client)


def send_to_slack_via_sns(message: Dict[str, Any], sns_client) -> None:
    if not SNS_TOPIC_ARN:
        print("SNS Topic ARN is missing")
        return

    payload = {
        "Level": message.get("level"),
        "Message": message.get("message"),
        "Timestamp": message.get("timestamp"),
    }

    try:
        response = sns_client.publish(
            TopicArn=SNS_TOPIC_ARN,
            Message=json.dumps(payload),
            Subject=f"CloudWatch Log Notification - {message.get('level')}",
        )
        print(f"Message sent to SNS Topic: {response['MessageId']}")
    except Exception as e:
        print(f"Failed to send message to SNS: {str(e)}")


if __name__ == "__main__":
    test_event = {
        "awslogs": {
            "data": json.dumps(
                {
                    "logEvents": [
                        {
                            "message": json.dumps(
                                {
                                    "timestamp": "2024-10-09T13:30:05Z",
                                    "level": "INFO",
                                    "message": "start_excel_reader_read_file",
                                    "logger": "root",
                                    "requestId": "806516ba-8cea-4eb6-9793-697fbd1ac173",
                                }
                            )
                        }
                    ]
                }
            )
        }
    }
    lambda_handler(test_event, None)
