import base64
import json
import os
from datetime import datetime
from pprint import pprint
from typing import Any, Dict, Optional

import boto3

SNS_TOPIC_ARN: str = os.getenv("SNS_TOPIC_ARN", "")


def lambda_handler(event: Dict[str, Any], context: Optional[Any]) -> None:
    log_events = event["awslogs"]["data"]

    if not log_events:
        print("No log events found")
        return

    decoded_data = base64.b64decode(log_events)
    json_data = json.loads(decoded_data)

    sns_client = boto3.client("sns")

    for log_event in json_data["logEvents"]:
        message = json.loads(log_event["message"])

        timestamp_iso = message["timestamp"]
        timestamp_dt = datetime.strptime(timestamp_iso, "%Y-%m-%dT%H:%M:%SZ")
        formatted_timestamp = timestamp_dt.strftime("%Y-%m-%d %H:%M:%S")
        message["timestamp"] = formatted_timestamp

        # Filter based on level or message content
        # if message.get(
        #     "level"
        # ) == "INFO" and "start_excel_reader_read_file" in message.get("message", ""):
        #     send_to_slack_via_sns(message, sns_client)
        send_to_slack_via_sns(message, sns_client)


def send_to_slack_via_sns(message: Dict[str, Any], sns_client) -> None:
    if not SNS_TOPIC_ARN:
        print("SNS Topic ARN is missing")
        return

    # payload = {
    #     "Timestamp": message.get("timestamp"),
    #     "Level": message.get("level"),
    #     "Message": message.get("message"),
    # }

    payload = f"""Date: {message.get("timestamp")}
    Level: {message.get("level")}
    Message: {message.get("message")}"""

    try:
        response = sns_client.publish(
            TopicArn=SNS_TOPIC_ARN,
            # Message=json.dumps(payload),
            Message=payload,
            Subject=f"CloudWatch Log Notification - {message.get('level')}",
        )
        print(f"Message sent to SNS Topic: {response['MessageId']}")
    except Exception as e:
        print(f"Failed to send message to SNS: {str(e)}")


if __name__ == "__main__":
    test_event = {
        "awslogs": {
            "data": base64.b64encode(
                json.dumps(
                    {
                        "logEvents": [
                            {
                                "message": json.dumps(
                                    {
                                        "timestamp": "2024-10-09T13:30:05Z",
                                        "level": "INFO",
                                        "message": "start_excel_reader_read_file",
                                        "logger": "root",
                                        "requestId": "806516ba-8cea-4eb6-9793-697fbd1ac173",
                                    }
                                )
                            }
                        ]
                    }
                ).encode()
            ).decode()
        }
    }
    pprint(test_event)
    lambda_handler(test_event, None)

# JSON for testing in the AWS console:
# {
#   "awslogs": {
#     "data": "eyJsb2dFdmVudHMiOiBbeyJtZXNzYWdlIjogIntcInRpbWVzdGFtcFwiOiBcIjIwMjQtMTAtMDlUMTM6MzA6MDVaXCIsIFwibGV2ZWxcIjogXCJJTkZPXCIsIFwibWVzc2FnZVwiOiBcInN0YXJ0X2V4Y2VsX3JlYWRlcl9yZWFkX2ZpbGVcIiwgXCJsb2dnZXJcIjogXCJyb290XCIsIFwicmVxdWVzdElkXCI6IFwiODA2NTE2YmEtOGNlYS00ZWI2LTk3OTMtNjk3ZmJkMWFjMTczXCJ9In1dfQ=="
#   }
# }
