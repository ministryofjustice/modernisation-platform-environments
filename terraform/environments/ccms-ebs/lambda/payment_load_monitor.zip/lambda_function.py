import base64
import json
import os
from datetime import datetime
from pprint import pprint
from typing import Any, Dict, Optional

import boto3

SNS_TOPIC_ARN: str = os.getenv("SNS_TOPIC_ARN", "")


def lambda_handler(event: Dict[str, Any], context: Optional[Any]) -> None:
    log_events = event["awslogs"]["data"]

    if not log_events:
        print("No log events found")
        return

    decoded_data = base64.b64decode(log_events)
    json_data = json.loads(decoded_data)

    sns_client = boto3.client("sns")

    for log_event in json_data["logEvents"]:
        message = json.loads(log_event["message"])

        formatted_timestamp = None
        if "timestamp" in message:
            timestamp_iso = message["timestamp"]
            timestamp_dt = datetime.strptime(timestamp_iso, "%Y-%m-%dT%H:%M:%SZ")
            formatted_timestamp = timestamp_dt.strftime("%Y-%m-%d %H:%M:%S")
            message["timestamp"] = formatted_timestamp
        elif "time" in message:
            timestamp_iso = message["time"]
            timestamp_dt = datetime.strptime(timestamp_iso, "%Y-%m-%dT%H:%M:%S.%fZ")
            formatted_timestamp = timestamp_dt.strftime("%Y-%m-%d %H:%M:%S")
            message["time"] = formatted_timestamp

        ts = None
        if formatted_timestamp:
            ts = formatted_timestamp

            # Filter based on level or message content
            # if message.get(
            #     "level"
            # ) == "INFO" and "start_excel_reader_read_file" in message.get("message", ""):
            #     send_to_slack_via_sns(message, sns_client)
        send_to_slack_via_sns(message, sns_client, ts)


def send_to_slack_via_sns(message: Dict[str, Any], sns_client, ts: str | None) -> None:
    if not SNS_TOPIC_ARN:
        print("SNS Topic ARN is missing")
        return

    if "message" in message:
        msg = message.get("message")
    elif "errorMessage" in message:
        msg = message.get("errorMessage")
    else:
        msg = "No message found in the log."

    if "level" in message:
        lvl = message.get("level")
    elif "log_level" in message:
        lvl = message.get("log_level")
    elif "type" in message:
        lvl = message.get("type")
    else:
        lvl = "Unknown"

    payload = f"""Date: {ts}
Level: {lvl}
Message: {msg}"""

    if "stackTrace" in message:
        payload = f"""{payload}
    stackTrace: {message.get("stackTrace")}"""

    raw_json = json.dumps(message, indent=4)

    payload = f"""{payload}\n
Raw log:
{raw_json}"""
    print(payload)

    # if not SNS_TOPIC_ARN:
    #     print("SNS Topic ARN is missing")
    #     return

    try:
        response = sns_client.publish(
            TopicArn=SNS_TOPIC_ARN,
            Message=payload,
            Subject=f"CloudWatch Log Notification: {lvl}",
        )
        print(f"Message sent to SNS Topic: {response['MessageId']}")
    except Exception as e:
        print(f"Failed to send message to SNS: {str(e)}")


if __name__ == "__main__":
    test_event = {
        "awslogs": {
            "data": base64.b64encode(
                json.dumps(
                    {
                        "logEvents": [
                            {
                                "message": json.dumps(
                                    {
                                        # "timestamp": "2024-10-09T13:30:05Z",
                                        # "level": "INFO",
                                        # "message": "start_excel_reader_read_file",
                                        # "logger": "root",
                                        # "requestId": "806516ba-8cea-4eb6-9793-697fbd1ac173",
                                        # "timestamp": "2024-10-09T13:30:51Z",
                                        # "log_level": "ERROR",
                                        # "errorMessage": "An error occurred (NoSuchKey) when calling the CopyObject operation: The specified key does not exist.",
                                        # "errorType": "NoSuchKey",
                                        # "requestId": "806516ba-8cea-4eb6-9793-697fbd1ac173",
                                        # "stackTrace": """[
                                        #       File "/var/task/lambda_function.py", line 48, in lambda_handler\n    filebucket.move_file_to_processed(filename)\n,
                                        #       File "/var/task/datalayer/s3_manager.py", line 45, in move_file_to_processed\n    self.move_file(filename, self.processed_file_dir + filename)\n,
                                        #       File "/var/task/datalayer/s3_manager.py", line 52, in move_file\n    response = self.s3.copy_object(\n,
                                        #       File "/var/runtime/botocore/client.py", line 565, in _api_call\n    return self._make_api_call(operation_name, kwargs)\n,
                                        #       File "/var/runtime/botocore/client.py", line 1021, in _make_api_call\n    raise error_class(parsed_response, operation_name)\n,
                                        # ]""",
                                        "time": "2024-10-16T13:19:11.191Z",
                                        "type": "platform.report",
                                        "record": {
                                            "requestId": "32b491ec-2968-4937-a7f4-a4a38ff93c58",
                                            "metrics": {
                                                "durationMs": 43765.37,
                                                "billedDurationMs": 43766,
                                                "memorySizeMB": 128,
                                                "maxMemoryUsedMB": 125,
                                            },
                                            "status": "success",
                                        },
                                    }
                                )
                            }
                        ]
                    }
                ).encode()
            ).decode()
        }
    }
    pprint(test_event)
    lambda_handler(test_event, None)

# JSON for testing in the AWS console:

# {
#     "timestamp": "2024-10-09T13:31:45Z",
#     "level": "ERROR",
#     "message": "upload_file_error: Must have a single .xlsx file. Found: []",
#     "logger": "root",
#     "requestId": "806516ba-8cea-4eb6-9793-697fbd1ac173"
# }
# =
# {
#   "awslogs": {
#     "data": "eyJsb2dFdmVudHMiOiBbeyJtZXNzYWdlIjogIntcInRpbWVzdGFtcFwiOiBcIjIwMjQtMTAtMDlUMTM6MzA6MDVaXCIsIFwibGV2ZWxcIjogXCJJTkZPXCIsIFwibWVzc2FnZVwiOiBcInN0YXJ0X2V4Y2VsX3JlYWRlcl9yZWFkX2ZpbGVcIiwgXCJsb2dnZXJcIjogXCJyb290XCIsIFwicmVxdWVzdElkXCI6IFwiODA2NTE2YmEtOGNlYS00ZWI2LTk3OTMtNjk3ZmJkMWFjMTczXCJ9In1dfQ=="
#   }
# }

# {
#     "timestamp": "2024-10-09T13:30:51Z",
#     "log_level": "ERROR",
#     "errorMessage": "An error occurred (NoSuchKey) when calling the CopyObject operation: The specified key does not exist.",
#     "errorType": "NoSuchKey",
#     "requestId": "806516ba-8cea-4eb6-9793-697fbd1ac173",
#     "stackTrace": [
#         "  File \"/var/task/lambda_function.py\", line 48, in lambda_handler\n    filebucket.move_file_to_processed(filename)\n",
#         "  File \"/var/task/datalayer/s3_manager.py\", line 45, in move_file_to_processed\n    self.move_file(filename, self.processed_file_dir + filename)\n",
#         "  File \"/var/task/datalayer/s3_manager.py\", line 52, in move_file\n    response = self.s3.copy_object(\n",
#         "  File \"/var/runtime/botocore/client.py\", line 565, in _api_call\n    return self._make_api_call(operation_name, kwargs)\n",
#         "  File \"/var/runtime/botocore/client.py\", line 1021, in _make_api_call\n    raise error_class(parsed_response, operation_name)\n"
#     ]
# }
# =
# {
#   "awslogs": {
#       "data": "eyJsb2dFdmVudHMiOiBbeyJtZXNzYWdlIjogIntcInRpbWVzdGFtcFwiOiBcIjIwMjQtMTAtMDlUMTM6MzA6NTFaXCIsIFwibG9nX2xldmVsXCI6IFwiRVJST1JcIiwgXCJlcnJvck1lc3NhZ2VcIjogXCJBbiBlcnJvciBvY2N1cnJlZCAoTm9TdWNoS2V5KSB3aGVuIGNhbGxpbmcgdGhlIENvcHlPYmplY3Qgb3BlcmF0aW9uOiBUaGUgc3BlY2lmaWVkIGtleSBkb2VzIG5vdCBleGlzdC5cIiwgXCJlcnJvclR5cGVcIjogXCJOb1N1Y2hLZXlcIiwgXCJyZXF1ZXN0SWRcIjogXCI4MDY1MTZiYS04Y2VhLTRlYjYtOTc5My02OTdmYmQxYWMxNzNcIiwgXCJzdGFja1RyYWNlXCI6IFwiW1xcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBGaWxlIFxcXCIvdmFyL3Rhc2svbGFtYmRhX2Z1bmN0aW9uLnB5XFxcIiwgbGluZSA0OCwgaW4gbGFtYmRhX2hhbmRsZXJcXG4gICAgZmlsZWJ1Y2tldC5tb3ZlX2ZpbGVfdG9fcHJvY2Vzc2VkKGZpbGVuYW1lKVxcbixcXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgRmlsZSBcXFwiL3Zhci90YXNrL2RhdGFsYXllci9zM19tYW5hZ2VyLnB5XFxcIiwgbGluZSA0NSwgaW4gbW92ZV9maWxlX3RvX3Byb2Nlc3NlZFxcbiAgICBzZWxmLm1vdmVfZmlsZShmaWxlbmFtZSwgc2VsZi5wcm9jZXNzZWRfZmlsZV9kaXIgKyBmaWxlbmFtZSlcXG4sXFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEZpbGUgXFxcIi92YXIvdGFzay9kYXRhbGF5ZXIvczNfbWFuYWdlci5weVxcXCIsIGxpbmUgNTIsIGluIG1vdmVfZmlsZVxcbiAgICByZXNwb25zZSA9IHNlbGYuczMuY29weV9vYmplY3QoXFxuLFxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBGaWxlIFxcXCIvdmFyL3J1bnRpbWUvYm90b2NvcmUvY2xpZW50LnB5XFxcIiwgbGluZSA1NjUsIGluIF9hcGlfY2FsbFxcbiAgICByZXR1cm4gc2VsZi5fbWFrZV9hcGlfY2FsbChvcGVyYXRpb25fbmFtZSwga3dhcmdzKVxcbixcXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgRmlsZSBcXFwiL3Zhci9ydW50aW1lL2JvdG9jb3JlL2NsaWVudC5weVxcXCIsIGxpbmUgMTAyMSwgaW4gX21ha2VfYXBpX2NhbGxcXG4gICAgcmFpc2UgZXJyb3JfY2xhc3MocGFyc2VkX3Jlc3BvbnNlLCBvcGVyYXRpb25fbmFtZSlcXG4sXFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF1cIn0ifV19=="
#     }
#   }

# {
#     "time": "2024-10-16T13:19:11.191Z",
#     "type": "platform.report",
#     "record": {
#         "requestId": "32b491ec-2968-4937-a7f4-a4a38ff93c58",
#         "metrics": {
#             "durationMs": 43765.37,
#             "billedDurationMs": 43766,
#             "memorySizeMB": 128,
#             "maxMemoryUsedMB": 125
#         },
#         "status": "success"
#     }
# }
# =
# {
#   "awslogs": {
#     "data": "eyJsb2dFdmVudHMiOiBbeyJtZXNzYWdlIjogIntcInRpbWVcIjogXCIyMDI0LTEwLTE2VDEzOjE5OjExLjE5MVpcIiwgXCJ0eXBlXCI6IFwicGxhdGZvcm0ucmVwb3J0XCIsIFwicmVjb3JkXCI6IHtcInJlcXVlc3RJZFwiOiBcIjMyYjQ5MWVjLTI5NjgtNDkzNy1hN2Y0LWE0YTM4ZmY5M2M1OFwiLCBcIm1ldHJpY3NcIjoge1wiZHVyYXRpb25Nc1wiOiA0Mzc2NS4zNywgXCJiaWxsZWREdXJhdGlvbk1zXCI6IDQzNzY2LCBcIm1lbW9yeVNpemVNQlwiOiAxMjgsIFwibWF4TWVtb3J5VXNlZE1CXCI6IDEyNX0sIFwic3RhdHVzXCI6IFwic3VjY2Vzc1wifX0ifV19=="
#   }
# }
