import json
import os
from datetime import datetime
from typing import Any, Dict, Literal, TypedDict

import boto3
from botocore.exceptions import ClientError


class CertificateDetail(TypedDict):
    CertificateArn: str
    DomainName: str
    Status: str
    NotAfter: str  # ISO 8601 date string
    RenewalEligibility: Literal["ELIGIBLE", "INELIGIBLE"]


class EventDetail(TypedDict):
    DaysToExpiry: int
    CertificateDetails: CertificateDetail


class EventBridgeEvent(TypedDict):
    version: str
    id: str
    detail_type: Literal[
        "ACM Certificate Approaching Expiration", "ACM Certificate Expired"
    ]
    source: Literal["aws.acm"]
    account: str
    time: str
    region: str
    resources: list[str]
    detail: EventDetail


def format_message(event: EventBridgeEvent) -> str:
    """Format the SNS notification message."""
    cert_details = event["detail"]["CertificateDetails"]
    domain = cert_details["DomainName"]
    expiry_date = datetime.fromisoformat(
        cert_details["NotAfter"].replace("Z", "+00:00")
    )
    days_to_expiry = event["detail"]["DaysToExpiry"]
    status = cert_details["Status"]
    renewal = cert_details["RenewalEligibility"]

    message = f"""Certificate Expiry Alert for {domain}

Status: {status}
Days until expiration: {days_to_expiry}
Expiration date: {expiry_date.strftime('%Y-%m-%d %H:%M:%S')} UTC
Renewal eligibility: {renewal}
Certificate ARN: {cert_details["CertificateArn"]}

Please take appropriate action to prevent service disruption."""

    return message


def publish_to_sns(message: str, subject: str) -> bool:
    """Publish message to SNS topic."""
    sns_client = boto3.client("sns")
    topic_arn: str = os.environ["SNS_TOPIC_ARN"]

    try:
        sns_client.publish(TopicArn=topic_arn, Message=message, Subject=subject)
        return True
    except ClientError as e:
        print(f"Error publishing to SNS: {str(e)}")
        return False


def lambda_handler(event: EventBridgeEvent, context: Any) -> Dict[str, Any]:
    """
    Lambda handler for processing ACM certificate events.

    Args:
        event: The EventBridge event containing certificate details
        context: Lambda context object

    Returns:
        Dict containing the execution status and details
    """
    try:
        cert_details = event["detail"]["CertificateDetails"]
        domain = cert_details["DomainName"]
        days_to_expiry = event["detail"]["DaysToExpiry"]

        if event["detail_type"] == "ACM Certificate Expired":
            subject = f"CRITICAL: SSL Certificate Expired - {domain}"
        else:
            subject = f"WARNING: SSL Certificate Expiring Soon - {domain} ({days_to_expiry} days)"

        message = format_message(event)
        success = publish_to_sns(message, subject)

        return {
            "statusCode": 200 if success else 500,
            "body": {
                "message": "Alert sent successfully"
                if success
                else "Failed to send alert",
                "certificateArn": cert_details["CertificateArn"],
                "domain": domain,
                "daysToExpiry": days_to_expiry,
            },
        }

    except Exception as e:
        print(f"Error processing event: {str(e)}")
        print(f"Event: {json.dumps(event)}")
        return {
            "statusCode": 500,
            "body": {"message": f"Error processing certificate event: {str(e)}"},
        }
