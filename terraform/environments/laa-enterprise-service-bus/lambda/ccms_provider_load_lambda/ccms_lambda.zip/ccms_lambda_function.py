import json
from typing import Dict, Any, List

from aws_lambda_powertools import Logger


from ccms.ccms_db_handler import CCMSDBHandler
from common.sns_message import SNSMessage, S3RefObject
from ccms.env_validator import CCMSConfig

logger = Logger(service="ccms-lambda-handler", level="DEBUG")


class CCMSProcessor:
    """Handles CCMS-specific business logic for processing SQS messages"""

    def __init__(self, ccms_config: CCMSConfig):
        self.ccms_config = ccms_config

    def parse_sns_message_from_sqs(self, sqs_record: Dict[str, Any]) -> SNSMessage:
        """Parse SNS message from SQS record"""
        try:
            # Extract SNS message from SQS record
            sns_data = json.loads(sqs_record['body'])

            # If the message is wrapped in SNS format
            if 'Message' in sns_data:
                message_data = json.loads(sns_data['Message'])
            else:
                message_data = sns_data

            # Parse file objects
            file_objects = []
            if 'file_Objects' in message_data:
                for file_obj_data in message_data['file_Objects']:
                    file_objects.append(
                        S3RefObject(status=file_obj_data.get('status', ''), s3_uri=file_obj_data.get('s3_uri', ''),
                                    file_name=file_obj_data.get('file_name', '')))

            # Create SNSMessage object
            sns_message = SNSMessage(file_Objects=file_objects, folder_name=message_data.get('folder_name', ''))

            logger.info(f"Parsed SNS message with folder: {sns_message.folder_name}")
            return sns_message

        except Exception as e:
            logger.error(f"Failed to parse SNS message from SQS record: {str(e)}")
            raise

    def process_sqs_record(self, record: Dict[str, Any]) -> bool:
        """Process a single SQS record"""
        try:
            logger.info(f"Processing SQS record: {record.get('messageId', 'unknown')}")

            # Parse SNS message from SQS record
            sns_message = self.parse_sns_message_from_sqs(record)

            # Extract folder name
            folder_name = sns_message.folder_name
            if not folder_name:
                logger.warning("No folder name found in SNS message")
                return False

            logger.info(f"Processing folder: {folder_name}")
            ccms_db_handler = CCMSDBHandler(self.ccms_config)
            # Call database procedure
            ccms_db_handler.execute_procedure(self.ccms_config.procedure, folder_name)

            return True

        except Exception as e:
            logger.error(f"Failed to process SQS record {record.get('messageId', 'unknown')}: {str(e)}")
            return False


@logger.inject_lambda_context()
def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Lambda handler for processing SQS messages containing SNS data
    """
    results = []

    try:
        # Validate and get environment variables using reusable validator
        ccms_config = CCMSConfig.from_env()
        logger.info(f"Processing SQS event with {len(event.get('Records', []))} records")

    except ValueError as e:
        logger.error(f"Environment variable validation failed: {str(e)}")
        # Create a single failed result for environment validation error
        results.append({
            'success': False,
            'error': str(e),
            'message_id': 'env_validation_error'
        })
        return create_response(results)

    try:
        # Initialize CCMS processor
        processor = CCMSProcessor(ccms_config)

        # Process each SQS record and collect results
        for i, record in enumerate(event.get('Records', [])):
            message_id = record.get('messageId', 'unknown')
            try:
                success = processor.process_sqs_record(record)
                results.append({
                    'record_index': i,
                    'success': success,
                    'message_id': message_id
                })
            except Exception as e:
                logger.error(f"Failed to process record {i}: {str(e)}")
                results.append({
                    'record_index': i,
                    'success': False,
                    'error': str(e),
                    'message_id': message_id
                })

        return create_response(results)

    except Exception as e:
        logger.error(f"Lambda execution failed: {str(e)}")
        # Create a single failed result for general execution error
        results.append({
            'success': False,
            'error': f"Internal server error: {str(e)}",
            'message_id': 'lambda_execution_error'
        })
        return create_response(results)


def create_response(results: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Create standardized Lambda response."""
    successful_count = sum(1 for result in results if result.get('success', False))
    total_count = len(results)

    response = {
        'statusCode': 200 if successful_count == total_count else 207,
        'body': json.dumps({
            'processed_records': total_count,
            'successful_records': successful_count,
            'failed_records': total_count - successful_count,
            'results': results
        })
    }

    logger.info(f"Processing complete: {successful_count}/{total_count} records successful")
    return response
