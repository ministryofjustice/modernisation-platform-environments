
class HubWorkflowError(Exception):
    """Base exception for workflow errors"""
    pass


class ProcedureExecutionError(HubWorkflowError):
    """Raised when procedure execution fails"""
    pass


class FileTransferError(HubWorkflowError):
    """Raised when file transfer fails"""
    pass
