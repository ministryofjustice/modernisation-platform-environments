import os
from dataclasses import dataclass
from typing import Dict
from common.secrets_utils import SecretsUtil

REQUIRED_ENV_VARS = {
    'PROCEDURE_SECRET_NAME': 'AWS Secrets Manager name for procedure configuration',
    'DB_SECRET_NAME': 'AWS Secrets Manager name for database credentials',
    'AWS_REGION': 'AWS region for services',
    'LD_LIBRARY_PATH': 'path to Oracle client libraries'
}


def validate_and_get_env_vars() -> Dict[str, str]:
    env_vars = {}
    missing_vars = []

    # Check for presence and non-empty values of required environment variables
    for var_name in REQUIRED_ENV_VARS:
        value = os.environ.get(var_name)
        if not value:
            missing_vars.append(var_name)
        else:
            env_vars[var_name] = value

    if missing_vars:
        raise ValueError(
            "Missing or empty required environment variables: " + ", ".join(missing_vars)
        )

    return env_vars


@dataclass
class CCMSConfig:
    """Configuration for the Hub Function Lambda"""
    procedure: str
    db_secret_name: str
    aws_region: str

    @classmethod
    def from_env(cls) -> 'CCMSConfig':
        """Creates CCMSConfig instance from environment variables."""
        env_vars = validate_and_get_env_vars()

        # Get procedure name from secret
        procedure_secret = SecretsUtil.get_secret(
            env_vars['PROCEDURE_SECRET_NAME'],
            env_vars['AWS_REGION']
        )

        return cls(
            procedure=procedure_secret.get('procedure_name'),
            db_secret_name=env_vars['DB_SECRET_NAME'],
            aws_region=env_vars['AWS_REGION']
        )
