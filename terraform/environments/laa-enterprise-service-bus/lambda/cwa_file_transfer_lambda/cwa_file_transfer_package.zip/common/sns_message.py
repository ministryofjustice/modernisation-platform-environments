from dataclasses import dataclass


@dataclass
class S3RefObject:
    folder_name: str
    procedure_folder_name: str


@dataclass
class SNSMessage:
    folder_name: str

    def to_dict(self):
        return {
            "folder_name": self.folder_name
        }
