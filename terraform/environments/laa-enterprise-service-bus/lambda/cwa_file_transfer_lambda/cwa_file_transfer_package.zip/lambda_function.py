import os
from datetime import datetime
from typing import Dict, Any

from aws_lambda_powertools.metrics import MetricUnit

from common.constants import FILE_GROUPS, create_response, HTTP_STATUS, get_logger_obj, get_metrics_obj
from common.db_settings import OracleDBSettings
from cwa_file_transfer.file_transfer_config import FileTransferConfig
from cwa_file_transfer.cwa_file_processor import CWAFileProcessor
from cwa_file_transfer.file_transfer_constants import SERVICE_NAME, NAMESPACE


logger = get_logger_obj(SERVICE_NAME)
metrics = get_metrics_obj(SERVICE_NAME, NAMESPACE)


@logger.inject_lambda_context
@metrics.log_metrics
def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    filename = event.get('filename')
    timestamp = event.get('timestamp')
    params = FileTransferConfig(filename, timestamp, logger)

    timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
    directory = get_directory_by_filename(filename)
    # Create dynamic output prefix
    output_prefix = f"HUB20/{directory}/"

    try:
        logger.info(f"Processing file: {filename} in directory: {directory}")
        filename_without_ext = os.path.splitext(filename)[0]
        s3_key = f"{output_prefix}{filename_without_ext}_{timestamp}.json"
        db_settings = OracleDBSettings.from_secret(params.db_secret_name, params.aws_region, logger)
        merger = CWAFileProcessor(params.s3_bucket, s3_key, db_settings, logger)

        result = merger.retrieve_and_stream_merge_json_parts(filename, table_name=params.table_name)

        file_result = {
            'filename': filename,
            'directory': directory,
            'status': result.get('status', 'unknown'),
            'parts_count': result.get('parts_count', 0),
            'total_records': result.get('total_records', 0),
            'file_size': result.get('file_size', 0),
            's3_uri': result.get('s3_uri', ''),
            's3_key': result.get('s3_key', ''),
            'output_prefix': output_prefix
            }
        metrics.add_metric(name="UploadSuccess", unit=MetricUnit.Count, value=1)
        metrics.add_dimension(name="FileName", value=filename)

        logger.info(f"Successfully processed {filename} in {directory}: {result.get('total_records', 0)} records")

        return create_response(HTTP_STATUS['OK'], file_result)

    except Exception as e:
        metrics.add_metric(name="UploadFailure", unit=MetricUnit.Count, value=1)
        metrics.add_dimension(name="FileName", value=filename)
        logger.exception(f"Error processing file merge request: {str(e)}")
        return create_response(HTTP_STATUS['Error'], {"status": "error", "error": str(e)})


def get_directory_by_filename(filename):
    for group in FILE_GROUPS:
        if filename in group['filenames']:
            return group['directory']
    raise ValueError("directory to upload not defined for given file")
