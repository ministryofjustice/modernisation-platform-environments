import json
import gc
import re
from datetime import datetime
from typing import Dict, Any, List,  Tuple
from cx_Oracle import DatabaseError

from aws_lambda_powertools import Logger

from db.db_connection_manager import DBConnectionManager
from db.db_settings import OracleDBSettings
from common.errors import JsonParseError
from cwa_file_transfer.cwa_file_uploader import CWAFileUploader


class CWAFileProcessor:
    DEFAULT_CHUNK_SIZE = 8192  # 8KB chunks for file operations
    MAX_MEMORY_PER_PART = 5 * 1024 * 1024  # 5MB per part in memory
    MAX_BLOB_CHUNKS = 1000  # Roughly 8MB limit
    JSON_FOOTER = '\n]'  # Simple array closing

    def __init__(self, s3_bucket: str, s3_key: str, db_settings: OracleDBSettings, logger: Logger) -> None:
        self.connection_manager = DBConnectionManager(db_settings, logger)
        self.s3_bucket = s3_bucket
        self.s3_key = s3_key
        self.db_settings = db_settings
        self.logger = logger
        self.timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
        self.chunk_size = self.DEFAULT_CHUNK_SIZE
        self.max_memory_per_part = self.MAX_MEMORY_PER_PART
        self.uploader = CWAFileUploader(logger, s3_bucket, s3_key)

    def retrieve_and_stream_merge_json_parts(
            self,
            filename: str,
            table_name: str
    ) -> Dict[str, Any]:

        try:
            self.logger.debug(f"Retrieving parts metadata for {filename}, table: {table_name}...")
            parts_metadata = self._validate_and_get_parts_metadata(filename, table_name)
            self.logger.info(f"Found {len(parts_metadata)} parts for {filename}")

            # Use the S3StreamUploader context manager for automatic cleanup
            with self.uploader:
                total_size = 0

                # Write simple array header - just opening bracket
                header_data = '['
                header_bytes = header_data.encode('utf-8')
                self.uploader.write(header_bytes)
                total_size += len(header_bytes)

                total_records = 0
                parts_count = len(parts_metadata)

                # Process each JSON part
                for i, part_metadata in enumerate(parts_metadata):
                    self.logger.debug(f"Processing part {part_metadata['seq_index']} ({i + 1}/{parts_count})")

                    part_data, records_count = self._stream_process_json_part(
                        part_metadata, table_name, is_first=(i == 0), is_last=(i == parts_count - 1)
                        )

                    if part_data:
                        part_bytes = part_data.encode('utf-8')
                        self.uploader.write(part_bytes)
                        total_size += len(part_bytes)

                    total_records += records_count
                    gc.collect()  # Force garbage collection after each part

                # Write footer
                footer_bytes = self.JSON_FOOTER.encode('utf-8')
                self.uploader.write(footer_bytes)
                total_size += len(footer_bytes)

                # The context manager will automatically complete the upload
                return self._create_success_response(
                    filename, parts_metadata, total_records, self.uploader.bucket, self.uploader.key, total_size
                    )

        except Exception as e:
            self.logger.error(f"Error in streaming merge: {str(e)}")
            self.connection_manager.handle_connection_error(e)
            raise DatabaseError(f"Streaming merge failed for {filename}: {str(e)}")

    def _validate_and_get_parts_metadata(self, filename: str, table_name: str) -> List[Dict[str, Any]]:
        """Validate and retrieve parts metadata"""
        parts_metadata = self._get_parts_metadata(filename, table_name)
        if not parts_metadata:
            raise DatabaseError(f"No JSON parts found for filename: {filename}")
        self.logger.debug(f"Found {len(parts_metadata)} parts for {filename}")
        return parts_metadata

    def _create_success_response(self, filename: str, parts_metadata: List[Dict[str, Any]],
                                 total_records: int, s3_bucket: str, s3_key: str, file_size: int) -> Dict[str, Any]:
        """Create success response dictionary"""
        self.logger.info(f"Successfully merged {len(parts_metadata)} "
                         f"parts to S3: {total_records} records, {file_size} bytes")

        return {
            'status': 'success',
            'filename': filename,
            'parts_count': len(parts_metadata),
            'total_records': total_records,
            's3_uri': f"s3://{s3_bucket}/{s3_key}",
            's3_key': s3_key,
            'file_size': file_size,
            'processing_method': 'streaming_merge'
        }

    def _get_parts_metadata(self, filename: str, table_name: str) -> List[Dict[str, Any]]:
        """Get lightweight metadata about parts without loading BLOB data"""
        self.logger.debug(f"Retrieving parts metadata for {filename}, table: {table_name}...")
        try:
            with self.connection_manager.create_cursor() as cursor:
                query = f"""
                    SELECT filename, seq_index, NVL(DBMS_LOB.GETLENGTH(chunk_clob), 0) AS blob_size
                    FROM {table_name}
                    WHERE filename = :filename
                    ORDER BY seq_index
                """

                cursor.execute(query, {'filename': filename})
                parts_metadata = []
                for row in cursor.fetchall():
                    filename_db, seq_index, blob_size = row
                    self.logger.debug(f"Filename: {filename_db}, Seq Index: {seq_index}, Blob Size: {blob_size}")
                    parts_metadata.append({
                        'filename': filename_db,
                        'seq_index': seq_index,
                        'blob_size': blob_size
                    })
                self.logger.info(f"Successfully retrieved parts metadata for {filename}, table: {table_name}.")
                return parts_metadata
        except Exception as e:
            self.logger.error(f"Error getting parts metadata: {str(e)}")
            self.connection_manager.handle_connection_error(e)
            raise DatabaseError(f"Failed to get parts metadata: {str(e)}")

    def _stream_process_json_part(
            self,
            part_metadata: Dict[str, Any],
            table_name: str,
            is_first: bool = False,
            is_last: bool = False
    ) -> Tuple[str, int]:
        """
        Stream process a single JSON part without loading entire content into memory
        Returns formatted JSON string and record count
        """
        try:
            with self.connection_manager.create_cursor() as cursor:
                query = f"""
                    SELECT chunk_clob
                    FROM {table_name}
                    WHERE filename = :filename AND seq_index = :seq_index
                """
                cursor.execute(query, {
                    'filename': part_metadata['filename'],
                    'seq_index': part_metadata['seq_index']
                })
                row = cursor.fetchone()
                if not row or not row[0]:
                    return "", 0

                json_blob = row[0]
                blob_data = self._read_blob_in_chunks(json_blob)

            try:
                # Clean the blob data before JSON parsing
                cleaned_data = self._clean_json_content(blob_data)
                json_data = json.loads(cleaned_data)
            except json.JSONDecodeError as je:
                self.logger.error(f"Invalid JSON in part {part_metadata['seq_index']}: {str(je)}")
                self.logger.error(f"Raw data sample: {blob_data[:200]}...")  # Log first 200 chars for debugging
                return "", 0

            formatted_data, record_count = self._format_json_for_merge(
                json_data, is_first
            )

            del json_data, blob_data
            gc.collect()

            return formatted_data, record_count
        except Exception as e:
            self.logger.error(f"Error processing JSON part {part_metadata['seq_index']}: {str(e)}")
            self.connection_manager.handle_connection_error(e)
            raise JsonParseError(e)

    def _read_blob_in_chunks(self, blob) -> str:
        """
        Read Oracle BLOB data in chunks to avoid memory issues
        """
        try:
            total_size = blob.size()
            if total_size == 0:
                return ""

            chunks = []
            offset = 1  # Oracle BLOB offset starts at 1
            bytes_read = 0

            while bytes_read < total_size:
                remaining = min(self.chunk_size, total_size - bytes_read)
                chunk = blob.read(offset, remaining)
                if not chunk:
                    break

                if isinstance(chunk, bytes):
                    chunk = chunk.decode('utf-8', errors='replace')

                chunks.append(chunk)
                offset += remaining
                bytes_read += remaining

                # Safety check to prevent excessive memory usage
                if len(chunks) > self.MAX_BLOB_CHUNKS:
                    self.logger.warning(f"BLOB size exceeds maximum chunk limit ({self.MAX_BLOB_CHUNKS})")
                    break

            result = ''.join(chunks)
            del chunks
            return result

        except Exception as e:
            self.logger.error(f"Error reading BLOB in chunks: {str(e)}")
            self.connection_manager.handle_connection_error(e)
            raise DatabaseError(f"Failed to read BLOB data: {str(e)}")

    def _clean_json_content(self, content: str) -> str:
        """
        Clean JSON content by removing HTTP chunked encoding and AWS headers
        """
        if not content:
            return content

        # Remove chunked encoding size indicators (hex numbers followed by \r\n)
        content = re.sub(r'^[0-9a-fA-F]+\r?\n', '', content, flags=re.MULTILINE)

        # Remove AWS headers (x-amz-* headers)
        content = re.sub(r'x-amz-[^:]+:[^\r\n]*\r?\n', '', content)

        # Remove trailing chunk size and extra whitespace
        content = re.sub(r'\r?\n0\r?\n.*$', '', content, flags=re.DOTALL)

        # Find the JSON content between [ and ] or { and }
        json_match = re.search(r'(\[.*\]|\{.*\})', content, re.DOTALL)
        if json_match:
            return json_match.group(1)

        return content.strip()

    def _format_json_for_merge(
            self,
            json_data: Any,
            is_first: bool,
    ) -> Tuple[str, int]:
        """Format JSON data for streaming merge"""
        try:
            records, record_count = self._extract_records(json_data)
            formatted_json = self._format_records_batch(records, is_first)
            return formatted_json, record_count
        except Exception as e:
            self.logger.error(f"Error formatting JSON for merge: {str(e)}")
            self.connection_manager.handle_connection_error(e)
            raise JsonParseError(e)

    def _extract_records(self, json_data: Any) -> Tuple[List, int]:
        """Extract records from various JSON data formats."""
        if isinstance(json_data, list):
            return json_data, len(json_data)

        if isinstance(json_data, dict) and 'data' in json_data and isinstance(json_data['data'], list):
            return json_data['data'], len(json_data['data'])

        # Handle single record case (dict or other JSON-serializable type)
        return [json_data], 1

    def _format_records_batch(self, records: List, is_first: bool) -> str:
        """Format a batch of records into JSON string."""
        formatted_records = []
        for i, record in enumerate(records):
            formatted_record = self._format_single_record(record, is_first and i == 0)
            formatted_records.append(formatted_record)
        return ''.join(formatted_records)

    def _format_single_record(self, record: Any, is_first_record: bool) -> str:
        """Format a single record with proper prefix and JSON encoding."""
        prefix = "" if is_first_record else ","
        json_str = json.dumps(record, separators=(',', ':'), default=str)
        return f"{prefix}\n  {json_str}"
