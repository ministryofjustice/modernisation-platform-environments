# python
from io import BytesIO
from typing import List, Dict, Optional

import boto3
from aws_lambda_powertools import Logger

logger = Logger(service="cwa-file-handler", level="DEBUG")


class CWAFileUploader:

    def __init__(self, bucket: str, key: str, part_size: int = 5 * 1024 * 1024):
        """
        :param bucket: S3 bucket name
        :param key: S3 object key
        :param part_size: minimum part size for multipart uploads (default 5MB)
        """
        self.s3_client = boto3.client('s3')
        self.bucket = bucket
        self.key = key
        self.part_size = part_size
        self.upload_id: Optional[str] = None
        self.parts: List[Dict[str, int]] = []
        self.part_number: int = 1
        self.buffer = BytesIO()
        self._started = False

    def start_upload(self) -> None:
        """Initialize multipart upload."""
        if self._started:
            return
        resp = self.s3_client.create_multipart_upload(
            Bucket=self.bucket,
            Key=self.key,
            ContentType='application/json'
        )
        self.upload_id = resp.get('UploadId')
        self._started = True
        logger.debug("Started multipart upload: %s", self.upload_id)

    def write(self, data: bytes) -> None:
        """Write data to internal buffer and upload parts when buffer reaches part_size."""
        if not isinstance(data, (bytes, bytearray)):
            raise TypeError("CWAFileUploader.write() expects bytes or bytearray")

        if not self._started:
            self.start_upload()

        self.buffer.write(data)

        if self.buffer.tell() >= self.part_size:
            self._upload_part()

    def _upload_part(self) -> None:
        """Upload current buffer content as a multipart upload part."""
        size = self.buffer.tell()
        if size == 0:
            return

        self.buffer.seek(0)
        part_data = self.buffer.read()
        try:
            resp = self.s3_client.upload_part(
                Bucket=self.bucket,
                Key=self.key,
                PartNumber=self.part_number,
                UploadId=self.upload_id,
                Body=part_data
            )
        except Exception:
            logger.exception("Failed uploading part %s for upload id %s", self.part_number, self.upload_id)
            raise

        etag = resp.get('ETag')
        self.parts.append({'ETag': etag, 'PartNumber': self.part_number})
        logger.debug("Uploaded part %s, ETag=%s", self.part_number, etag)
        self.part_number += 1

        # reset buffer
        self.buffer = BytesIO()

    def complete_upload(self) -> Dict:
        """Complete multipart upload. If no parts uploaded, perform a single put_object with buffer content."""
        if not self._started:
            # nothing to do
            return {}

        # upload any remaining buffered data as a final part
        if self.buffer.tell() > 0:
            self._upload_part()

        result = {}
        if self.parts:
            # AWS expects parts in ascending PartNumber order
            multipart = {'Parts': sorted(self.parts, key=lambda p: p['PartNumber'])}
            result = self.s3_client.complete_multipart_upload(
                Bucket=self.bucket,
                Key=self.key,
                UploadId=self.upload_id,
                MultipartUpload=multipart
            )
            logger.info("Completed multipart upload: %s", result)
        else:
            # no parts uploaded (empty content) -> put_object
            self.buffer.seek(0)
            body = self.buffer.read()
            result = self.s3_client.put_object(Bucket=self.bucket, Key=self.key, Body=body, ContentType='application/json')
            logger.info("Put object (single part) to %s/%s", self.bucket, self.key)

        # reset state
        self.upload_id = None
        self.parts = []
        self.part_number = 1
        self.buffer = BytesIO()
        self._started = False

        return result

    def abort_upload(self) -> None:
        """Abort an in-progress multipart upload."""
        if not self._started or not self.upload_id:
            return
        try:
            self.s3_client.abort_multipart_upload(Bucket=self.bucket, Key=self.key, UploadId=self.upload_id)
            logger.info("Aborted multipart upload: %s", self.upload_id)
        except Exception:
            logger.exception("Failed to abort multipart upload: %s", self.upload_id)
        finally:
            self.upload_id = None
            self.parts = []
            self.part_number = 1
            self.buffer = BytesIO()
            self._started = False

    def __enter__(self):
        self.start_upload()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type:
            # error occurred; abort
            try:
                self.abort_upload()
            except Exception:
                logger.exception("Exception during abort in __exit__")
        else:
            try:
                self.complete_upload()
            except Exception:
                logger.exception("Exception during complete in __exit__")
                raise