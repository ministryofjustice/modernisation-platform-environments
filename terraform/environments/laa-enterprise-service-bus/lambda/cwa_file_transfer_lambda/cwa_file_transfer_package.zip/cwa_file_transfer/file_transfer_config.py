import os

from common.secrets_utils import SecretsUtil

from aws_lambda_powertools import Logger
logger = Logger(service="cwa-file-processor", level="DEBUG")

class FileTransferConfig:
    def __init__(self, filename, timestamp):
        self.filename = filename
        self.table_name_secret = os.environ.get('TABLE_NAME_SECRET')
        self.s3_bucket = os.environ.get('TARGET_BUCKET')
        self.db_secret_name = os.environ.get('DB_SECRET_NAME')
        self.aws_region = os.environ.get('AWS_REGION')
        self.timestamp = timestamp
        logger.info(f"table_name_secret: {self.table_name_secret}")
        self._validate()
        logger.info(f"table_name_secret: {self.table_name_secret}")
        secret = SecretsUtil.get_secret(self.table_name_secret)
        logger.info(f"secret: {secret}")
        self.table_name = secret.get('table')

    def _validate(self):
        if not self.filename:
            raise ValueError("Missing required parameter: filename")

        if not self.table_name_secret:
            raise EnvironmentError("Missing environment variable: TABLE_NAME_SECRET")

        if not self.s3_bucket:
            raise EnvironmentError("Missing environment variable: TARGET_BUCKET")

        if not self.db_secret_name:
            raise EnvironmentError("Missing environment variable: DB_SECRET_NAME")

        if not self.aws_region:
            raise EnvironmentError("Missing environment variable: AWS_REGION")

        if not self.timestamp:
            raise ValueError(f"Directory not found for filename: {self.timestamp}")

        if not self.table_name_secret:
            logger.info(f"table_name_secret: {self.table_name_secret}")
            raise ValueError(f"Secret value not found for key: {self.table_name_secret}")

    def to_dict(self):
        return {
            'table_name': self.table_name,
            's3_bucket': self.s3_bucket,
            'db_secret_name': self.db_secret_name,
            'aws_region': self.aws_region,
            'filename': self.filename,
            'timestamp': self.timestamp
            }
