import os

SERVICE_NAME = os.getenv("SERVICE_NAME", "cwa-file-transfer")
NAMESPACE = os.getenv("NAMESPACE", "HUB20-CWA-NS")
