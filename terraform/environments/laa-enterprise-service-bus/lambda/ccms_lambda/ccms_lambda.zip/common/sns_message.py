from dataclasses import dataclass
from typing import List


@dataclass
class S3RefObject:
    status: str
    s3_uri: str
    file_name: str


@dataclass
class SNSMessage:
    file_Objects: List[S3RefObject]
    folder_name: str
