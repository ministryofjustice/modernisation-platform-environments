import os
import gzip
import json
import base64
import logging
import urllib3
import boto3

# Set up logging for Lambda diagnostics
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Caches the Slack webhook URL for reuse within a Lambda container
SLACK_WEBHOOK_URL_CACHE = None

def get_slack_webhook_url():
    """
    Fetches and caches the Slack webhook URL from AWS Secrets Manager using environment variable.
    """
    global SLACK_WEBHOOK_URL_CACHE
    if SLACK_WEBHOOK_URL_CACHE:
        return SLACK_WEBHOOK_URL_CACHE
    secret_name = os.environ.get("SLACK_WEBHOOK_URL")
    region_name = os.environ.get("AWS_REGION", "eu-west-2")

    if not secret_name:
        logger.error("Environment variable SLACK_WEBHOOK_URL not set!")
        raise Exception("SLACK_WEBHOOK_URL env missing")

    client = boto3.client("secretsmanager", region_name=region_name)
    get_secret_value_response = client.get_secret_value(SecretId=secret_name)
    secret = get_secret_value_response.get("SecretString", "")
    secret_dict = json.loads(secret)
    url = secret_dict.get("SLACK_WEBHOOK_URL")
    if not url:
        logger.error("Key SLACK_WEBHOOK_URL missing in Secret")
        raise Exception("SLACK_WEBHOOK_URL key missing in secret JSON")
    SLACK_WEBHOOK_URL_CACHE = url
    return url

# Create an HTTP manager for outbound requests
http = urllib3.PoolManager()

def post_to_slack_blocks(blocks):
    """
    Sends a Slack Block Kit message to the configured webhook URL.
    """
    webhook_url = get_slack_webhook_url()
    payload = {
        "attachments": [
            {
                "color": "#FFA500",  # Orange sidebar for alert styling
                "blocks": blocks
            }
        ]
    }
    encoded_payload = json.dumps(payload).encode('utf-8')
    response = http.request(
        'POST',
        webhook_url,
        body=encoded_payload,
        headers={'Content-Type': 'application/json'}
    )
    return response

def generate_log_url(account_id, region, lambda_function_name):
    """
    Constructs a direct CloudWatch log group URL for the given Lambda function.
    """
    if not lambda_function_name or not account_id or not region:
        return None
    # Custom encoding for CloudWatch Log Group path
    encoded_function_name = lambda_function_name.replace('/', '$252F')
    encoded_log_group = f"$252Faws$252Flambda$252F{encoded_function_name}"
    url = (
        f"https://{account_id}.{region}.console.aws.amazon.com/"
        f"cloudwatch/home?region={region}#logsV2:log-groups/log-group/{encoded_log_group}"
    )
    return url

def build_slack_blocks(account_id, environment, service, lambda_arn, error_message, log_url=None):
    """
    Constructs the Slack Block Kit message structure with all relevant Lambda info and error details.
    """
    blocks = [
        {
            "type": "header",      # Main alert header
            "text": {
                "type": "plain_text",
                "text": "Lambda Invocation Alert Message",
                "emoji": True
            }
        },
        {"type": "divider"},     # Visual separation
        {
            "type": "section",    # Main content: AWS and error info
            "text": {
                "type": "mrkdwn",
                "text": (
                    f"*AWS Account:*\n{account_id}\n\n"
                    f"*Environment:*\n{environment}\n\n"
                    f"*Service:*\n{service}\n\n"
                    f"*Lambda ARN:*\n`{lambda_arn}`\n\n"
                    f"*Error Message:*\n{error_message}"
                )
            },
            "accessory": {
                "type": "image",  # Thumbnail for visual identification
                "image_url": "https://img.icons8.com/?size=100&id=20732&format=png&color=000000",
                "alt_text": "computer thumbnail"
            }
        }
    ]
    # Optionally add direct log group link if available
    if log_url:
        blocks.extend([
            {"type": "divider"},
            {
                "type": "context",
                "elements": [
                    {
                        "type": "mrkdwn",
                        "text": f"🔍 View logs: <{log_url}|Open in Monitoring Tool>"
                    }
                ]
            }
        ])
    return blocks

def lambda_handler(event, context):
    """
    AWS Lambda entrypoint. Processes incoming CloudWatch logs or direct invocation events,
    extracts errors, builds Slack notification, and posts to Slack alert channel.
    """
    logger.info("Received event keys: %s", list(event.keys()))
    messages = []
    region = os.environ.get("AWS_REGION", "eu-west-2")

    # Handle CloudWatch log subscription event
    if "awslogs" in event:
        logger.info("Processing CloudWatch Logs payload")
        try:
            # Decode and decompress log payload
            decoded = base64.b64decode(event["awslogs"]["data"])
            decompressed = gzip.decompress(decoded)
            log_data = json.loads(decompressed)
            for log_event in log_data.get("logEvents", []):
                raw_msg = log_event.get("message", "")
                try:
                    msg_json = json.loads(raw_msg)
                except json.JSONDecodeError:
                    messages.append(raw_msg)
                    continue
                # Extract alert fields needed for Slack notification
                error_message = msg_json.get("message", "No error message found")
                environment = msg_json.get("environment", "UnknownEnvironment")
                service = msg_json.get("service", "UnknownService")
                lambda_function_name = msg_json.get("function_name")
                account_id = None
                lambda_arn = None
                if lambda_function_name:
                    # Parse account ID from self ARN context
                    account_id = context.invoked_function_arn.split(":")[4] if context and context.invoked_function_arn else "UnknownAccount"
                    lambda_arn = f"arn:aws:lambda:{region}:{account_id}:function:{lambda_function_name}"
                else:
                    lambda_arn = msg_json.get(
                        "function_arn",
                        context.invoked_function_arn if context and hasattr(context, "invoked_function_arn") else "UnknownLambdaARN"
                    )
                    account_id = lambda_arn.split(":")[4] if ":" in lambda_arn else "UnknownAccount"
                # Generate direct CloudWatch log group link for error context
                log_url = generate_log_url(account_id, region, lambda_function_name)
                # Build, post Slack alert
                alert_message_blocks = build_slack_blocks(account_id, environment, service, lambda_arn, error_message, log_url)
                response = post_to_slack_blocks(alert_message_blocks)
                if response.status != 200:
                    logger.error(f"Failed to send to Slack: {response.data.decode('utf-8')}")
        except Exception as e:
            logger.exception("Failed to process CloudWatch log payload: %s", e)
            messages.append(f"Error processing CloudWatch logs event: {str(e)}")

    # Handle direct/manual invocation with function_arn/message fields
    elif "function_arn" in event and "message" in event:
        error_message = event.get("message", "No error message found")
        environment = event.get("environment", "UnknownEnvironment")
        service = event.get("service", "UnknownService")
        lambda_function_name = event.get("function_name")
        account_id = None
        lambda_arn = None
        if lambda_function_name:
            # Use provided account_id or parse from context if missing
            account_id = event.get("account_id")
            if not account_id and context and context.invoked_function_arn:
                account_id = context.invoked_function_arn.split(":")[4]
            lambda_arn = f"arn:aws:lambda:{region}:{account_id}:function:{lambda_function_name}"
        else:
            lambda_arn = event.get("function_arn", "UnknownLambdaARN")
            account_id = lambda_arn.split(":")[4] if ":" in lambda_arn else "UnknownAccount"
        log_url = generate_log_url(account_id, region, lambda_function_name)
        alert_message_blocks = build_slack_blocks(account_id, environment, service, lambda_arn, error_message, log_url)
        response = post_to_slack_blocks(alert_message_blocks)
        if response.status != 200:
            logger.error(f"Failed to send to Slack: {response.data.decode('utf-8')}")
        return {"statusCode": 200, "body": "Alert sent"}

    # Handles fallback/unstructured events for troubleshooting
    else:
        msg = event.get("message") or event.get("error") or json.dumps(event)
        messages.append(msg)

    # If there are fallback messages, send them to Slack as a plain message
    if messages:
        fallback_alert = "\n".join(messages)
        blocks = [
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": fallback_alert
                }
            }
        ]
        try:
            response = post_to_slack_blocks(blocks)
            if response.status != 200:
                logger.error(f"Failed to send fallback message to Slack: {response.data.decode('utf-8')}")
        except Exception as e:
            logger.exception("Failed to publish fallback Slack message: %s", e)

    return {"statusCode": 200, "body": "Alert sent"}
