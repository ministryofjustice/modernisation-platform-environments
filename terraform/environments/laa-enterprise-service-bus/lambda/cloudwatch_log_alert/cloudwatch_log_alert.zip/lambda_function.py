import os
import gzip
import json
import base64
import logging
import urllib3

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Read webhook URL from Lambda environment variable (set by Terraform)
SLACK_WEBHOOK_URL = os.environ.get("SLACK_WEBHOOK_URL")

http = urllib3.PoolManager()

def post_to_slack(message):
    payload = {"text": message}
    encoded_payload = json.dumps(payload).encode('utf-8')
    response = http.request(
        'POST',
        SLACK_WEBHOOK_URL,
        body=encoded_payload,
        headers={'Content-Type': 'application/json'}
    )
    return response

def lambda_handler(event, context):
    logger.info("Received event keys: %s", list(event.keys()))
    messages = []

    if "awslogs" in event:
        logger.info("Processing CloudWatch Logs payload")
        try:
            decoded = base64.b64decode(event["awslogs"]["data"])
            decompressed = gzip.decompress(decoded)
            log_data = json.loads(decompressed)
            logger.info("Decoded log data: %s", json.dumps(log_data, indent=2))
            for log_event in log_data.get("logEvents", []):
                msg = log_event.get("message", "")
                messages.append(msg)
            logger.info("Extracted %d messages", len(messages))
        except Exception as e:
            logger.exception("Failed to process CloudWatch log payload: %s", e)
            messages.append(f"Error processing CloudWatch logs event: {str(e)}")
    else:
        logger.info("Manual test path triggered")
        msg = event.get("message") or event.get("error") or json.dumps(event)
        messages.append(msg)
        logger.info("Manual message extracted: %s", msg)

    if not messages:
        logger.warning("No messages to send, exiting")
        return {"statusCode": 200, "body": "No messages"}

    alert_message = "Lambda Error Alert:\n" + "\n".join(messages)

    try:
        response = post_to_slack(alert_message)
        logger.info("Slack response status: %d, body: %s", response.status, response.data.decode('utf-8'))
        if response.status != 200:
            logger.error(f"Failed to send to Slack: {response.data.decode('utf-8')}")
    except Exception as e:
        logger.exception("Failed to publish to Slack: %s", e)
        print(f"Failed to publish to Slack: {str(e)}")

    return {"statusCode": 200, "body": "Alert sent"}
