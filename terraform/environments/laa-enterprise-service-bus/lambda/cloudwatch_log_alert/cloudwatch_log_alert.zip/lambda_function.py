import os
import boto3
import gzip
import json
import base64

sns = boto3.client('sns')
ALERT_TOPIC_ARN = os.environ['ALERT_TOPIC_ARN']

def lambda_handler(event, context):
    # CloudWatch Logs data is base64 encoded and gzipped
    cw_data = event['awslogs']['data']
    decoded = base64.b64decode(cw_data)
    decompressed = gzip.decompress(decoded)
    log_data = json.loads(decompressed)

    messages = []
    for log_event in log_data['logEvents']:
        messages.append(log_event['message'])

    # Combine all error messages into one SNS notification
    alert_message = f"Lambda Error Alert:\n" + "\n".join(messages)

    sns.publish(
        TopicArn=ALERT_TOPIC_ARN,
        Subject="Lambda Error Alert",
        Message=alert_message
    )

    return {
        'statusCode': 200,
        'body': 'Alert sent'
    }