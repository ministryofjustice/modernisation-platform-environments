import json
import os
from typing import Dict, Any

from aws_lambda_powertools import Logger

from common.constants import HTTP_STATUS, create_response
from common.errors import NotificationError
from common.sns_handler import SNSNotifier
from common.sns_message import SNSMessage


logger = Logger(service="cwa-file-handler", level="DEBUG")


def send_notification(
        sns_notifier: SNSNotifier, topic_name: str, folder_name: str
        ) -> dict:
    """Send SNS notifications to multiple topics based on directory configuration"""

    try:
        topic_message = SNSMessage(
            folder_name=folder_name
            )
        result = sns_notifier.send_notification(topic_name, topic_message)
        logger.info(f"Sent notification to {topic_name} with folder: {folder_name}")
        return result

    except Exception as e:
        logger.error(f"Error sending SNS message {topic_name}: {str(e)}")
        raise NotificationError(str(e))


@logger.inject_lambda_context
def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    try:
        aws_region = os.environ.get('AWS_REGION')
        provider_topic = os.environ.get('PROVIDER_TOPIC')
        provider_banks_topic = os.environ.get('PROVIDER_BANKS_TOPIC')
        folder_name = event.get('timestamp')

        # Validate environment variables
        if not aws_region or not provider_topic or not provider_banks_topic:
            logger.error("Missing one or more required environment variables.")
            raise ValueError("Environment variables AWS_REGION, PROVIDER_TOPIC, and PROVIDER_BANKS_TOPIC must be set.")

        # Validate event data
        if not folder_name:
            logger.error("Missing 'folder_name' in event.")
            raise ValueError("Event must include 'folder_name'.")

        logger.info("Environment variables validated")

        sns_notifier = SNSNotifier(aws_region)

        provider_result = send_notification(sns_notifier, topic_name=provider_topic, folder_name=folder_name)
        provider_banks_result = send_notification(sns_notifier, topic_name=provider_banks_topic, folder_name=folder_name)
        return create_response(HTTP_STATUS['OK'], {
            'provider_result': provider_result,
            'provider_banks_result': provider_banks_result
            })

    except ValueError as e:
        logger.exception("Environment variables not defined")
        return create_response(HTTP_STATUS['VALIDATION_ERROR'], {"message": str(e)})
    except Exception as e:
        logger.exception("Error in lambda execution")
        return create_response(HTTP_STATUS['INTERNAL_ERROR'], {"message": str(e)})