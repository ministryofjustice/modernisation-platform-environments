import os
from typing import Dict, Any

from common.constants import HTTP_STATUS, create_response, get_logger_obj, get_metrics_obj
from common.errors import NotificationError
from common.sns_handler import SNSNotifier
from common.sns_message import SNSMessage
from aws_lambda_powertools.metrics import MetricUnit

SERVICE_NAME = os.getenv("SERVICE_NAME", "cwa-sns-service")
NAMESPACE = os.getenv("NAMESPACE", "CWASNSNotificationService")

logger = get_logger_obj(SERVICE_NAME)
metrics = get_metrics_obj(SERVICE_NAME, NAMESPACE)


def send_notification(
        sns_notifier: SNSNotifier, topic_name: str, folder_name: str
        ) -> dict:
    """Send SNS notifications to multiple topics based on directory configuration"""

    try:
        topic_message = SNSMessage(
            folder_name=folder_name
            )
        result = sns_notifier.send_notification(topic_name, topic_message)
        logger.info(f"Sent notification to {topic_name} with folder: {folder_name}")
        return result

    except Exception as e:
        logger.error(f"Error sending SNS message {topic_name}: {str(e)}")
        raise NotificationError(str(e))


@logger.inject_lambda_context
@metrics.log_metrics
def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    try:
        aws_region = os.environ.get('AWS_REGION')
        provider_topic = os.environ.get('PROVIDER_TOPIC')
        provider_banks_topic = os.environ.get('PROVIDER_BANKS_TOPIC')
        folder_name = event.get('timestamp')

        # Validate environment variables
        if not aws_region or not provider_topic or not provider_banks_topic:
            logger.error("Missing one or more required environment variables.")
            raise ValueError("Environment variables AWS_REGION, PROVIDER_TOPIC, and PROVIDER_BANKS_TOPIC must be set.")

        # Validate event data
        if not folder_name:
            logger.error("Missing 'folder_name' in event.")
            raise ValueError("Event must include 'folder_name'.")

        logger.info("Environment variables validated")

        sns_notifier = SNSNotifier(logger, aws_region)

        provider_result = send_notification(sns_notifier,
                                            topic_name=provider_topic,
                                            folder_name=folder_name)
        provider_banks_result = send_notification(sns_notifier,
                                                  topic_name=provider_banks_topic,
                                                  folder_name=folder_name)
        metrics.add_metric(name="CWASNSNotificationSuccess", unit=MetricUnit.Count, value=1)
        metrics.add_dimension(name="folder_name", value=folder_name)
        return create_response(HTTP_STATUS['OK'], {
            'provider_result': provider_result,
            'provider_banks_result': provider_banks_result
            })

    except ValueError as e:
        metrics.add_metric(name="CWASNSNotificationValidationError", unit=MetricUnit.Count, value=1)
        logger.exception("Environment variables not defined")
        return create_response(HTTP_STATUS['VALIDATION_ERROR'], {"message": str(e)})
    except Exception as e:
        metrics.add_metric(name="CWASNSNotificationFailure", unit=MetricUnit.Count, value=1)
        logger.exception("Error in lambda execution")
        return create_response(HTTP_STATUS['INTERNAL_ERROR'], {"message": str(e)})
