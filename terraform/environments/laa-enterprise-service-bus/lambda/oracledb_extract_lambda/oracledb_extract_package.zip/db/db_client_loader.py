import os
import oracledb
from aws_lambda_powertools import Logger


class OracleClientLoader:
    """Manages Oracle client initialization as a singleton"""
    _client_initialized = False

    @classmethod
    def initialize_client(cls, logger: Logger):
        if cls._client_initialized:
            logger.info("Oracle client already initialized, skipping initialization")
            return

        wallet_path = "/var/task/wallet_dir"
        os.environ["TNS_ADMIN"] = wallet_path
        oracle_lib_path = os.environ.get('LD_LIBRARY_PATH')


        logger.info(f"LD_LIBRARY_PATH set to: {oracle_lib_path}")

        try:
            oracledb.init_oracle_client(lib_dir=oracle_lib_path, config_dir=wallet_path)

            cls._client_initialized = True
            logger.info(f"Oracle client initialized successfully from {oracle_lib_path}")
        except Exception as e:
            error_msg = str(e).lower()
            if "already been initialized" in error_msg or "already initialized" in error_msg:
                cls._client_initialized = True
                logger.info("Oracle client was already initialized by another process")
            else:
                logger.error(f"Failed to initialize Oracle client: {str(e)}")
                raise

    @classmethod
    def is_initialized(cls) -> bool:
        return cls._client_initialized
