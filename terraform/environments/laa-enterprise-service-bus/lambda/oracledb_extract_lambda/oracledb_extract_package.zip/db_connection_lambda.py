import oracledb
import os

from db.db_settings import OracleDBSettings
from aws_lambda_powertools import Logger

logger = Logger("DEBUG")

def lambda_handler(event, context):
    try:

        oracle_lib_path = os.environ.get('LD_LIBRARY_PATH')
        secret_name = os.environ.get('DB_SECRET_NAME')
        # Set Oracle client library path if needed
        oracledb.init_oracle_client(lib_dir=oracle_lib_path)

        settings = OracleDBSettings.from_secret(secret_name)
        # Connect to the Oracle DB
        connection = oracledb.connect(
            user=settings.username,
            password=settings.password,
            dsn= "(DESCRIPTION=(ADDRESS=(PROTOCOL=tcps)(HOST=cwa-prod-db3.aws.prd.legalservices.gov.uk)(port=2484))(connect_data=(service_name=CWA)))" # e.g., "host:port/service_name"
            )
        logger.info("Successfully connected to Oracle DB", {connection.username}, {connection.dsn})

        cursor = connection.cursor()
        cursor.execute("SELECT 'Hello from Oracle DB!' FROM dual")
        result = cursor.fetchone()


        return {
            'statusCode': 200,
            'body': result[0]
            }

    except Exception as e:
        return {
            'statusCode': 500,
            'body': str(e)
            }