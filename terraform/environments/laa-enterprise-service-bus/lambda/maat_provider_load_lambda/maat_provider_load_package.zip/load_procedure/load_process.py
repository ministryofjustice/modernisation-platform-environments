import json
from typing import Dict, Any, List

from aws_lambda_powertools import Logger


from load_procedure.load_db_handler import LoadDBHandler
from common.sns_message import SNSMessage, S3RefObject
from load_procedure.env_validator import LoadConfig

logger = Logger(service="load-process-handler", level="DEBUG")


class LoadProcessor:
    """Handles Load-specific business logic for processing SQS messages"""

    def __init__(self, ccms_config: LoadConfig):
        self.ccms_config = ccms_config

    def parse_sns_message_from_sqs(self, sqs_record: Dict[str, Any]) -> SNSMessage:
        """Parse SNS message from SQS record"""
        try:
            # Extract SNS message from SQS record
            sns_data = json.loads(sqs_record['body'])

            # If the message is wrapped in SNS format
            if 'Message' in sns_data:
                message_data = json.loads(sns_data['Message'])
            else:
                message_data = sns_data

            folder = message_data.get('folder_name', '')
            if not folder:
                raise ValueError("No folder name found in SNS message")

            sns_message = SNSMessage(folder_name=folder)

            logger.info(f"Parsed SNS message with folder: {sns_message.folder_name}")
            return sns_message

        except Exception as e:
            logger.error(f"Failed to parse SNS message from SQS record: {str(e)}")
            raise

    def process_sqs_record(self, record: Dict[str, Any]) -> bool:
        """Process a single SQS record"""
        try:
            logger.info(f"Processing SQS record: {record.get('messageId', 'unknown')}")

            # Parse SNS message from SQS record
            sns_message = self.parse_sns_message_from_sqs(record)

            # Extract folder name
            folder_name = sns_message.folder_name
            if not folder_name:
                logger.warning("No folder name found in SNS message")
                return False

            logger.info(f"Processing folder: {folder_name}")
            load_db_handler = LoadDBHandler(self.ccms_config)
            # Call database procedure
            load_db_handler.execute_procedure(self.ccms_config.procedure, folder_name)

            return True

        except Exception as e:
            logger.error(f"Failed to process SQS record {record.get('messageId', 'unknown')}: {str(e)}")
            raise

