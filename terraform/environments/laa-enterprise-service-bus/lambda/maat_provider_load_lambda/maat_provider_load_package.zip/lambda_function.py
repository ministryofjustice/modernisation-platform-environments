import json
from typing import Dict, Any, List

from aws_lambda_powertools import Logger


from load_procedure.load_db_handler import LoadDBHandler
from common.sns_message import SNSMessage, S3RefObject
from load_procedure.env_validator import LoadConfig
from load_procedure.load_process import LoadProcessor


logger = Logger(service="maat-lambda-function", level="DEBUG")

@logger.inject_lambda_context()
def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Lambda handler for processing SQS messages containing SNS data
    """
    results = []

    try:
        # Validate and get environment variables using reusable validator
        load_config = LoadConfig.from_env()
        logger.info(f"Processing SQS event with {len(event.get('Records', []))} records")

    except ValueError as e:
        logger.error(f"Environment variable validation failed: {str(e)}")
        # Create a single failed result for environment validation error
        results.append({
            'success': False,
            'error': str(e),
            'message_id': 'env_validation_error'
        })
        return create_response(results)

    try:
        # Initialize CCMS processor
        processor = LoadProcessor(load_config)

        # Process each SQS record and collect results
        for i, record in enumerate(event.get('Records', [])):
            message_id = record.get('messageId', 'unknown')
            try:
                success = processor.process_sqs_record(record)
                results.append({
                    'record_index': i,
                    'success': success,
                    'message_id': message_id
                })
            except Exception as e:
                logger.error(f"Failed to process record {i}: {str(e)}")
                results.append({
                    'record_index': i,
                    'success': False,
                    'error': str(e),
                    'message_id': message_id
                })

        return create_response(results)

    except Exception as e:
        logger.error(f"Lambda execution failed: {str(e)}")
        # Create a single failed result for general execution error
        results.append({
            'success': False,
            'error': f"Internal server error: {str(e)}",
            'message_id': 'lambda_execution_error'
        })
        return create_response(results)


def create_response(results: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Create standardized Lambda response."""
    successful_count = sum(1 for result in results if result.get('success', False))
    total_count = len(results)

    response = {
        'statusCode': 200 if successful_count == total_count else 207,
        'body': json.dumps({
            'processed_records': total_count,
            'successful_records': successful_count,
            'failed_records': total_count - successful_count,
            'results': results
        })
    }

    logger.info(f"Processing complete: {successful_count}/{total_count} records successful")
    return response
