import os
from datetime import datetime

import boto3

ssm_client = boto3.client('ssm')

def lambda_handler(event, context):
    ccms_timestamp = os.environ['CCMS_TIMESTAMP']
    ccr_timestamp = os.environ['CCR_TIMESTAMP']
    cclf_timestamp = os.environ['CCLF_TIMESTAMP']
    maat_timestamp = os.environ['MAAT_TIMESTAMP']

    ccms_timestamp_val = ssm_client.get_parameter(Name=ccms_timestamp, WithDecryption=True)['Parameter']['Value']
    ccr_timestamp_val = ssm_client.get_parameter(Name=ccr_timestamp, WithDecryption=True)['Parameter']['Value']
    cclf_timestamp_val = ssm_client.get_parameter(Name=cclf_timestamp, WithDecryption=True)['Parameter']['Value']
    maat_timestamp_val = ssm_client.get_parameter(Name=maat_timestamp, WithDecryption=True)['Parameter']['Value']

    timestamps = [
        ccms_timestamp_val,
        ccr_timestamp_val,
        cclf_timestamp_val,
        maat_timestamp_val
        ]

    datetime_objects = [datetime.strptime(ts, '%Y%m%d%H%M%S') for ts in timestamps]
    min_timestamp = min(datetime_objects)

    return {
        'statusCode': 200,
        'body': f"{ccms_timestamp_val}, {ccr_timestamp_val}, {cclf_timestamp_val}, {maat_timestamp_val}, {min_timestamp.strftime('%Y%m%d%H%M%S')}"
        }
