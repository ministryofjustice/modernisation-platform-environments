import os
import re
from datetime import datetime
from aws_lambda_powertools.metrics import MetricUnit
import boto3
from common.constants import get_logger_obj, get_metrics_obj, ENVIRONMENT


SERVICE_NAME = os.getenv("SERVICE_NAME", "purge-lambda-service")
LOG_LEVEL = os.getenv("LOG_LEVEL", "DEBUG")
AWS_REGION = os.getenv("AWS_REGION", "eu-west-2")


logger = get_logger_obj(SERVICE_NAME)
metrics = get_metrics_obj(SERVICE_NAME, "HUB20-PURGE-DATA-NS")


@logger.inject_lambda_context()
@metrics.log_metrics
def lambda_handler(event, context):
    s3 = boto3.client('s3', region_name=AWS_REGION)
    min_timestamp = get_min_timestamp()
    min_timestamp_str = min_timestamp.strftime('%Y%m%d%H%M%S')
    bucket_name = os.environ['TARGET_BUCKET']
    if not bucket_name:
        raise ValueError("TARGET_BUCKET value not defined")
    if not min_timestamp:
        raise Exception("Minimum timestamp value not defined")
    try:
        # List objects in the bucket
        response = s3.list_objects_v2(Bucket=bucket_name, Prefix="HUB20/provider")
        response_banks = s3.list_objects_v2(Bucket=bucket_name, Prefix="HUB20/provider_banks")

        response_objects = []
        if not response_banks or not response:
            raise Exception(f"No data found for {bucket_name}")

        if 'Contents' in response:
            response_objects.extend(response['Contents'])
        if 'Contents' in response_banks:
            response_objects.extend(response_banks['Contents'])

        timestamp_pattern = re.compile(r'_(\d{14})\.json$')
        count = 0
        for obj in response_objects:
            key = obj['Key']
            match = timestamp_pattern.search(key)
            if match:
                ts_str = match.group(1)
                try:
                    ts = datetime.strptime(ts_str, '%Y%m%d%H%M%S')
                    if ts <= min_timestamp:
                        logger.debug(f"Deleting: {key}")
                        s3.delete_object(Bucket=bucket_name, Key=key)
                        count += 1
                except ValueError:
                    logger.error(f"Invalid timestamp format in: {key}")
        logger.info(f"Deleted {count} objects for {bucket_name} for timestamp {min_timestamp}")
        metrics.add_dimension(name="environment", value=ENVIRONMENT)
        metrics.add_metric(name="InvocationFailureCount", unit=MetricUnit.Count, value=0)
        return {
            'statusCode': 200,
            'body':
                {
                    "timestamp": min_timestamp_str,
                    "num_of_deleted_files": count
                }
            }
    except ValueError as e:
        metrics.add_dimension(name="environment", value=ENVIRONMENT)
        metrics.add_metric(name="InvocationFailureCount", unit=MetricUnit.Count, value=1)
        logger.error(f"ValueError: {str(e)}")
        raise ValueError(f"ValueError: {str(e)}")
    except Exception as e:
        metrics.add_dimension(name="environment", value=ENVIRONMENT)
        metrics.add_metric(name="InvocationFailureCount", unit=MetricUnit.Count, value=1)
        logger.error(f"Exception: {str(e)}")
        raise Exception(f"Exception: {str(e)}")


def get_min_timestamp():
    ccms_timestamp = os.environ['CCMS_TIMESTAMP']
    ccr_timestamp = os.environ['CCR_TIMESTAMP']
    cclf_timestamp = os.environ['CCLF_TIMESTAMP']
    maat_timestamp = os.environ['MAAT_TIMESTAMP']
    ssm_client = boto3.client('ssm', region_name=AWS_REGION)
    if not ccms_timestamp or not ccr_timestamp or not cclf_timestamp or not maat_timestamp:
        raise ValueError("Missing CCMS_TIMESTAMP or CCR_TIMESTAMP or MAAT_TIMESTAMP environment variables")

    ccms_timestamp_val = ssm_client.get_parameter(Name=ccms_timestamp, WithDecryption=True)['Parameter']['Value']
    ccr_timestamp_val = ssm_client.get_parameter(Name=ccr_timestamp, WithDecryption=True)['Parameter']['Value']
    cclf_timestamp_val = ssm_client.get_parameter(Name=cclf_timestamp, WithDecryption=True)['Parameter']['Value']
    maat_timestamp_val = ssm_client.get_parameter(Name=maat_timestamp, WithDecryption=True)['Parameter']['Value']

    if not ccms_timestamp_val or not ccr_timestamp_val or not cclf_timestamp_val or not maat_timestamp_val:
        raise Exception("Missing timestamp values in parameters")

    timestamps = [
        ccms_timestamp_val,
        ccr_timestamp_val,
        cclf_timestamp_val,
        maat_timestamp_val
        ]
    datetime_objects = [datetime.strptime(ts, '%Y%m%d%H%M%S') for ts in timestamps]
    min_timestamp = min(datetime_objects)
    return min_timestamp
