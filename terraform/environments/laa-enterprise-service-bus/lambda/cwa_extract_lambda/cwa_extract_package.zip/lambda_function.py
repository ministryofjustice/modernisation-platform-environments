import json
from typing import Dict, Any

from aws_lambda_powertools import Logger
from aws_lambda_powertools.utilities.typing import LambdaContext

from common.constants import FILE_NAMES
from cwa_extract_lambda.cwa_extract_config import CWAExtractConfig
from cwa_extract_lambda.cwa_db_handler import DBHandler
from common.errors import (
    ProcedureExecutionError,
    HubWorkflowError
)

# Constants
CONTENT_TYPE_JSON = "application/json"

HTTP_STATUS = {
    'OK': 200,
    'ERROR': 400,
    'VALIDATION_ERROR': 422,
    'INTERNAL_ERROR': 500
}

logger = Logger(service="cwa-provider-extract-lambda", level="DEBUG")


def create_response(status_code: int, body: Dict[str, Any]) -> Dict[str, Any]:
    """Create a standardized HTTP response"""
    return {
        "statusCode": status_code,
        "body": json.dumps(body),
        "headers": {"Content-Type": CONTENT_TYPE_JSON}
    }


class CWAMainProcess:
    def __init__(self, config: CWAExtractConfig):
        self.config = config
        self.db_handler = DBHandler(config)

    def execute_procedure_step(self, procedure: str) -> dict:
        return self.db_handler.execute_procedure(procedure)

    def process(self, procedure: str) -> dict:
        try:
            procedure_result = self.execute_procedure_step(procedure)
            logger.debug(f"Procedure execution result: {procedure_result}")

            return create_response(HTTP_STATUS['OK'], {
                "procedure_execution": procedure_result
            })
        except ProcedureExecutionError as e:
            logger.error(f"Error processing procedure {procedure}: {str(e)}")
            raise HubWorkflowError(str(e))
        except Exception as e:
            logger.error(f"Unexpected error in procedure {procedure}: {str(e)}")
            raise HubWorkflowError(f"Unexpected workflow error: {str(e)}")


@logger.inject_lambda_context
def lambda_handler(event: dict, context: LambdaContext) -> dict:
    try:
        config = CWAExtractConfig.from_env()
        logger.info("Environment variables validated")
        workflow = CWAMainProcess(config)
        result = workflow.process(config.procedure)
        if result['statusCode'] == 200:
            logger.info(f"Successfully executed procedure {config.procedure}")
            return {
                'files': FILE_NAMES
                }
        else:
            logger.error(f"Failed to execute procedure {config.procedure}")
        logger.info(
            f"Successfully executed procedure {config.procedure} with status code {result['statusCode']}"
        )
        return create_response(
            HTTP_STATUS['ERROR'],
            {"message": f"Failed to execute procedure {config.procedure}"}
            ) # Return the last result for backward compatibility
    except ValueError as e:
        logger.exception("Environment variables not defined")
        return create_response(HTTP_STATUS['VALIDATION_ERROR'], {"message": str(e)})
    except HubWorkflowError as e:
        logger.exception("HUB Workflow execution error")
        return create_response(
            HTTP_STATUS['ERROR'],
            {"message": str(e)}
        )
    except Exception as e:
        logger.exception("Error in lambda execution")
        return create_response(HTTP_STATUS['INTERNAL_ERROR'], {"message": str(e)})
