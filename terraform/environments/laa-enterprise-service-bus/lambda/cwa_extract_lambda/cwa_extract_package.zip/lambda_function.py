from datetime import datetime

from aws_lambda_powertools.utilities.typing import LambdaContext
from aws_lambda_powertools.metrics import MetricUnit


from common.constants import FILE_NAMES, HTTP_STATUS, create_response, get_logger_obj, get_metrics_obj
from cwa_extract_lambda.cwa_extract_config import CWAExtractConfig
from cwa_extract_lambda.cwa_db_handler import DBHandler
from common.errors import (
    ProcedureExecutionError,
    HubWorkflowError
)
from cwa_extract_lambda.cwa_extract_constants import SERVICE_NAME, NAMESPACE


logger = get_logger_obj(SERVICE_NAME)
metrics = get_metrics_obj(SERVICE_NAME, NAMESPACE)


class CWAMainProcess:
    def __init__(self, config: CWAExtractConfig):
        self.config = config
        self.db_handler = DBHandler(config, logger)

    def execute_procedure_step(self, procedure: str) -> dict:
        return self.db_handler.execute_procedure(procedure)

    def process(self, procedure: str) -> dict:
        try:
            procedure_result = self.execute_procedure_step(procedure)
            logger.info(f"Procedure execution result: {procedure_result}")

            return create_response(HTTP_STATUS['OK'], {
                "procedure_execution": procedure_result
            })
        except ProcedureExecutionError as e:
            logger.error(f"Error processing procedure {procedure}: {str(e)}")
            raise HubWorkflowError(str(e))
        except Exception as e:
            logger.error(f"Unexpected error in procedure {procedure}: {str(e)}")
            raise HubWorkflowError(f"Unexpected workflow error: {str(e)}")


@logger.inject_lambda_context
@metrics.log_metrics
def lambda_handler(event: dict, context: LambdaContext) -> dict:
    try:
        config = CWAExtractConfig.from_env(logger)
        logger.info("Environment variables validated")

        workflow = CWAMainProcess(config)
        result = workflow.process(config.procedure)
        if result['statusCode'] == 200:
            logger.info(f"Successfully executed procedure {config.procedure}")
            metrics.add_metric(name="ProcedureSuccess", unit=MetricUnit.Count, value=1)
            timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
            event_success = {
                'files': FILE_NAMES,
                'timestamp': timestamp
                }
            return create_response(HTTP_STATUS['OK'], event_success)

        logger.error(f"Failed to execute procedure {config.procedure}")
        metrics.add_metric(name="ProcedureFailure", unit=MetricUnit.Count, value=1)
        return create_response(
            HTTP_STATUS['ERROR'],
            {"message": f"Failed to execute procedure {config.procedure}"}
            )
    except ValueError as e:
        logger.exception("Environment variables not defined")
        metrics.add_metric(name="ValidationError", unit=MetricUnit.Count, value=1)
        return create_response(HTTP_STATUS['VALIDATION_ERROR'], {"message": str(e)})
    except HubWorkflowError as e:
        logger.exception("HUB Workflow execution error")
        metrics.add_metric(name="ProcedureFailure", unit=MetricUnit.Count, value=1)
        return create_response(
            HTTP_STATUS['ERROR'],
            {"message": str(e)}
        )
    except Exception as e:
        logger.exception("Error in lambda execution")
        metrics.add_metric(name="UnhandledError", unit=MetricUnit.Count, value=1)
        return create_response(HTTP_STATUS['INTERNAL_ERROR'], {"message": str(e)})
