
class HubWorkflowError(Exception):
    """Base exception for workflow errors"""
    pass


class ProcedureExecutionError(HubWorkflowError):
    """Raised when procedure execution fails"""
    pass


class FileTransferError(Exception):
    """Raised when file transfer fails"""
    pass


class NotificationError(Exception):
    """Raised when file transfer fails"""
    pass

class JsonParseError(Exception):
    """Raised when file transfer fails"""
    pass

