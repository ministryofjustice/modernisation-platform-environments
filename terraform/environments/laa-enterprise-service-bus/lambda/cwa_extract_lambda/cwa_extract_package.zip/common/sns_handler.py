import hashlib
import json
import boto3
from aws_lambda_powertools import Logger

from common.sns_message import SNSMessage

logger = Logger(service="sns-handler", level="DEBUG")


class SNSNotifier:
    def __init__(self, region_name: str = "eu-west-2"):
        self.sns_client = boto3.client('sns',  region_name)

    def _is_fifo_topic(self, topic_arn: str) -> bool:
        return topic_arn.split(':')[-1].endswith('.fifo')

    def _generate_message_group_id(self, message: SNSMessage) -> str:
        return message.folder_name or "default-group"

    def _generate_deduplication_id(self, message: SNSMessage) -> str:
        message_content = json.dumps(message.to_dict(), sort_keys=True)
        return hashlib.md5(message_content.encode()).hexdigest()

    def send_notification(self, topic_arn: str, message: SNSMessage) -> dict:
        try:
            publish_params = {
                'TopicArn': topic_arn,
                'Message': json.dumps(message.to_dict())
            }
            if self._is_fifo_topic(topic_arn):
                publish_params['MessageGroupId'] = self._generate_message_group_id(message)
                publish_params['MessageDeduplicationId'] = self._generate_deduplication_id(message)
                logger.debug(f"Publishing to FIFO topic with MessageGroupId: {publish_params['MessageGroupId']}")

            response = self.sns_client.publish(**publish_params)

            return {"status": "success", "message_id": response['MessageId']}

        except Exception as e:
            logger.exception(f"Error sending SNS notification, {str(e)}")
            raise
