FILE_GROUPS = [
    {
        'filenames': [
            'ccms_vendor_sites.json',
            'ccms_vendors.json',
            'ccms_vendor_contacts.json',
            'xxlsc_vendor_sites.json',
            'provider_sites.json'
            ],
        'directory': 'provider'
        },
    {
        'filenames': [
            'bank_acct.json',
            'bank_acct_uses.json',
            'bank_branch.json'
            ],
        'directory': 'provider_banks'
        }
    ]

FILE_NAMES = [
    {"filename": "ccms_vendor_sites.json"},
    {"filename": "ccms_vendors.json"},
    {"filename": "ccms_vendor_contacts.json"},
    {"filename": "xxlsc_vendor_sites.json"},
    {"filename": "provider_sites.json"},
    {"filename": "bank_acct.json"},
    {"filename": "bank_acct_uses.json"},
    {"filename": "bank_branch.json"}
    ]
