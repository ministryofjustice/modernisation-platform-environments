import cx_Oracle
from aws_lambda_powertools import Logger
from typing import Optional

from common.db_settings import OracleDBSettings
from common.db_client_loader import OracleClientLoader

logger = Logger(service="db-connection-manager", level="DEBUG")


class DBConnectionManager:
    def __init__(self, settings: OracleDBSettings):
        self.settings = settings
        self._connection: Optional[cx_Oracle.Connection] = None
        if not OracleClientLoader.is_initialized():
            OracleClientLoader.initialize_client()

    def get_connection(self) -> cx_Oracle.Connection:
        if self._connection is None or not self._is_connection_valid():
            logger.debug("Creating new database connection")
            self._connection = cx_Oracle.connect(
                user=self.settings.username,
                password=self.settings.password,
                dsn=self.settings.dsn
            )
            logger.debug("Database connection established")
        return self._connection

    def _is_connection_valid(self) -> bool:
        if self._connection is None:
            return False
        try:
            cursor = self._connection.cursor()
            cursor.execute("SELECT 1 FROM DUAL")
            cursor.fetchone()
            cursor.close()
            return True
        except Exception as e:
            logger.warning(f"Cached connection is invalid: {str(e)}")
            self._close_connection()
            return False

    def _close_connection(self):
        if self._connection:
            try:
                self._connection.close()
                logger.debug("Database connection closed")
            except Exception as e:
                logger.warning(f"Error closing connection: {str(e)}")
            finally:
                self._connection = None

    def handle_connection_error(self, error: Exception):
        if "connection" in str(error).lower():
            logger.warning(f"Connection error detected, closing connection: {str(error)}")
            self._close_connection()

    def create_cursor(self) -> cx_Oracle.Cursor:
        connection = self.get_connection()
        return connection.cursor()

    def __del__(self):
        self._close_connection()