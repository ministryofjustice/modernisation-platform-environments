from dataclasses import dataclass
from common.secrets_utils import SecretsUtil


@dataclass
class OracleDBSettings:
    username: str
    password: str
    dsn: str

    @classmethod
    def from_secret(cls, secret: str, region_name: str = "eu-west-2") -> 'OracleDBSettings':
        """
        Creates OracleDBSettings instance from AWS Secrets Manager.

        Returns:
            OracleDBSettings: Instance populated with database settings
        """

        secret = SecretsUtil.get_secret(secret, region_name)
        return OracleDBSettings(
            username=secret.get('Username'),
            password=secret.get('Password'),
            dsn=secret.get('DSN')
        )
