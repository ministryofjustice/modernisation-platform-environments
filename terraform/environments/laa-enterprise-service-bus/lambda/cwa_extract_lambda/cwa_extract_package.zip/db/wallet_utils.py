import os
import tempfile
import zipfile
import boto3

from common.constants import get_logger_obj, get_metrics_obj, ENVIRONMENT, SERVICE_NAME, NAMESPACE
from aws_lambda_powertools.metrics import MetricUnit

logger = get_logger_obj(SERVICE_NAME)
metrics = get_metrics_obj(SERVICE_NAME, NAMESPACE)
AWS_REGION = os.environ.get("AWS_REGION", "eu-west-2")
bucket = os.environ.get("WALLET_BUCKET")
wallet_obj = os.environ.get("WALLET_OBJ")
s3 = boto3.client('s3', region_name=AWS_REGION)


def download_wallet():
    try:
        tmp_dir = tempfile.gettempdir()
        wallet_zip_path = os.path.join(tmp_dir, "wallet_dir_zip")
        wallet_extract_dir = tmp_dir

        s3.download_file(bucket, wallet_obj, wallet_zip_path)

        with zipfile.ZipFile(wallet_zip_path, "r") as zip_ref:
            zip_ref.extractall(wallet_extract_dir)

            return wallet_extract_dir
    except Exception as e:
        logger.error(f"Failed to download required wallet: {str(e)}")
        metrics.add_dimension(name="environment", value=ENVIRONMENT)
        metrics.add_metric(name="InvocationFailureCount", unit=MetricUnit.Count, value=1)
        raise Exception(str(e))
