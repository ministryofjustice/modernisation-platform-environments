import os

SERVICE_NAME = os.getenv("SERVICE_NAME", "cwa-extract-lambda")
NAMESPACE = os.getenv("NAMESPACE", "CWAExtractProcess")
