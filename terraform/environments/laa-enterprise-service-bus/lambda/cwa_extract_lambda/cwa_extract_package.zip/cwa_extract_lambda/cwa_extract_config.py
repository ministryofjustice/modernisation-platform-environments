import os
from dataclasses import dataclass
from typing import Dict

from common.secrets_utils import SecretsUtil
from aws_lambda_powertools import Logger


@dataclass
class CWAExtractConfig:
    """Configuration for the Hub Function Lambda"""
    procedure: str
    db_secret_name: str
    aws_region: str

    REQUIRED_ENV_VARS = {
        'PROCEDURES_CONFIG': 'AWS Secrets Manager name containing procedures configuration',
        'DB_SECRET_NAME': 'AWS Secrets Manager name for database credentials',
        'AWS_REGION': 'AWS region for services'
    }

    @classmethod
    def from_env(cls, logger: Logger) -> 'CWAExtractConfig':
        """Creates HubFunctionConfig instance from environment variables."""
        env_vars = cls._validate_and_get_env_vars()
        procedures = cls._load_procedure(
            env_vars['PROCEDURES_CONFIG'],
            env_vars['AWS_REGION'],
            logger
        )

        return cls(
            procedure=procedures,
            db_secret_name=env_vars['DB_SECRET_NAME'],
            aws_region=env_vars['AWS_REGION']
        )

    @classmethod
    def _load_procedure(cls, secret_name: str, region: str, logger: Logger) -> str:
        try:
            logger.debug(f"Calling aws secret manager Procedure config using secret: {secret_name}")
            procedure_name = SecretsUtil.get_secret(secret_name, region, logger)
            procedure = procedure_name.get('procedure_name')
            return procedure
        except Exception as e:
            raise ValueError(f"Failed to load procedures configuration: {str(e)}")

    @classmethod
    def _validate_and_get_env_vars(cls) -> Dict[str, str]:
        env_vars = {}
        missing_vars = []

        # Check for presence and non-empty values of required environment variables
        for var_name in cls.REQUIRED_ENV_VARS:
            value = os.environ.get(var_name)
            if not value:
                missing_vars.append(f"{var_name}")
            else:
                env_vars[var_name] = value

        if missing_vars:
            raise ValueError(
                "Missing or empty required environment variables: " + ", ".join(missing_vars)
            )
        return env_vars
