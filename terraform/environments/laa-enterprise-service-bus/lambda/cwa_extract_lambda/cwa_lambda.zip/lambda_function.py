import json
from typing import Dict, Any

from aws_lambda_powertools import Logger
from aws_lambda_powertools.utilities.typing import LambdaContext
from utils.s3_handler import S3Handler
from utils.sns_handler import SNSNotifier
from utils.db_handler import DBHandler
from utils.models import (
    HubFunctionConfig,
    ProcedureConfig,
    ProcedureExecutionError,
    FileTransferError,
    HubWorkflowError
)
from utils.sns_message import SNSMessage

# Constants
CONTENT_TYPE_JSON = "application/json"

HTTP_STATUS = {
    'OK': 200,
    'ERROR': 400,
    'VALIDATION_ERROR': 422,
    'INTERNAL_ERROR': 500
}

logger = Logger(service="hub-2.0-lambda")


def create_response(status_code: int, body: Dict[str, Any]) -> Dict[str, Any]:
    """Create a standardized HTTP response"""
    return {
        "statusCode": status_code,
        "body": json.dumps(body),
        "headers": {"Content-Type": CONTENT_TYPE_JSON}
    }


class HubFunctionWorkflow:
    def __init__(self, config: HubFunctionConfig):
        self.config = config
        self.db_handler = DBHandler(config)
        self.s3_handler = S3Handler()
        self.sns_notifier = SNSNotifier(config.aws_region)

    def execute_procedure_step(self, procedure: ProcedureConfig) -> dict:
        result = self.db_handler.execute_procedure(procedure.name)
        if not result:
            raise ProcedureExecutionError(f"Failed to execute procedure: {procedure.name}")
        return result

    def transfer_single_file(self, file_path: str, file_name: str) -> Dict[str, Any]:
        try:
            return self.s3_handler.upload_file_to_s3(file_path, self.config.target_bucket)
        except Exception as e:
            logger.error(f"Error transferring file {file_name}: {str(e)}")
            return {"status": "error", "error": str(e)}

    def transfer_files_step(self, procedure: ProcedureConfig) -> SNSMessage:
        try:
            transfer_results = self.s3_handler.transfer_files_to_s3(procedure, self.config.target_bucket)
            return transfer_results
        except Exception as e:
            logger.error(f"Error transferring files for procedure {procedure.name}: {str(e)}")
            raise FileTransferError(f"Error transferring files for procedure {procedure.name}: {str(e)}")

    def send_notification_step(self, transfer_result: SNSMessage) -> dict:
        return self.sns_notifier.send_notification(self.config.sns_topic, transfer_result)

    def process(self, procedure: ProcedureConfig) -> dict:
        try:
            procedure_result = self.execute_procedure_step(procedure)
            transfer_result = self.transfer_files_step(procedure)
            notification_result = self.send_notification_step(transfer_result)
            return create_response(HTTP_STATUS['OK'], {
                "procedure_execution": procedure_result,
                "file_transfer": transfer_result,
                "notification": notification_result
            })
        except (ProcedureExecutionError, FileTransferError) as e:
            logger.error(f"Error processing procedure {procedure.name}: {str(e)}")
            raise HubWorkflowError(str(e))
        except Exception as e:
            logger.error(f"Unexpected error in procedure {procedure.name}: {str(e)}")
            raise HubWorkflowError(f"Unexpected workflow error: {str(e)}")


@logger.inject_lambda_context
def lambda_handler(event: dict, context: LambdaContext) -> dict:
    try:
        config = HubFunctionConfig.from_env()
        logger.info("Environment variables validated")
        workflow = HubFunctionWorkflow(config)
        results = [workflow.process(procedure) for procedure in config.procedures.values()]
        return results[-1]  # Return the last result for backward compatibility
    except ValueError as e:
        logger.exception("Environment variables not defined")
        return create_response(HTTP_STATUS['VALIDATION_ERROR'], {"message": str(e)})
    except HubWorkflowError as e:
        logger.exception("HUB Workflow execution error")
        return create_response(
            HTTP_STATUS['ERROR'],
            {"message": str(e)}
        )
    except Exception as e:
        logger.exception("Error in lambda execution")
        return create_response(HTTP_STATUS['INTERNAL_ERROR'], {"message": str(e)})
