import json
from collections import defaultdict
from typing import Dict, Any, List

from aws_lambda_powertools import Logger
from aws_lambda_powertools.utilities.typing import LambdaContext

from utils.provider_config import HubFunctionConfig, ProcedureConfig
from utils.s3_handler import S3Handler
from utils.sns_handler import SNSNotifier
from utils.db_handler import DBHandler
from utils.models import (
    ProcedureExecutionError,
    FileTransferError,
    HubWorkflowError
)
from utils.sns_message import SNSMessage, S3RefObject

# Constants
CONTENT_TYPE_JSON = "application/json"

HTTP_STATUS = {
    'OK': 200,
    'ERROR': 400,
    'VALIDATION_ERROR': 422,
    'INTERNAL_ERROR': 500
}

logger = Logger(service="cwa-provider-extract-lambda")


def create_response(status_code: int, body: Dict[str, Any]) -> Dict[str, Any]:
    """Create a standardized HTTP response"""
    return {
        "statusCode": status_code,
        "body": json.dumps(body),
        "headers": {"Content-Type": CONTENT_TYPE_JSON}
    }


class HubFunctionWorkflow:
    def __init__(self, config: HubFunctionConfig):
        self.config = config
        self.db_handler = DBHandler(config)
        self.s3_handler = S3Handler()
        self.sns_notifier = SNSNotifier(config.aws_region)

    def execute_procedure_step(self, procedure: ProcedureConfig) -> dict:
        return self.db_handler.execute_procedure(procedure.name)

    def transfer_files_step(self, procedure: ProcedureConfig) -> SNSMessage:
        try:
            transfer_results = self.s3_handler.transfer_files_to_s3(procedure, self.config.target_bucket)
            return transfer_results
        except Exception as e:
            logger.error(f"Error transferring files for procedure {procedure.name}: {str(e)}")
            raise FileTransferError(f"Error transferring files for procedure {procedure.name}: {str(e)}")

    def _group_files_by_sns_topic(self, procedure: ProcedureConfig,
                                  transfer_result: SNSMessage) -> Dict[str, List[S3RefObject]]:
        """Group transferred files by their corresponding SNS topics"""
        topic_files_map = defaultdict(list)

        # Create a mapping from file names to their SNS topics based on directory config
        file_to_topic_map = {}
        for dir_path, dir_config in procedure.files_dirs.items():
            for file_name in dir_config.files:
                file_to_topic_map[file_name] = dir_config.sns_topic

        # Group S3RefObjects by their SNS topics
        for s3_ref in transfer_result.file_Objects:
            sns_topic = file_to_topic_map.get(s3_ref.file_name, self.config.default_sns_topic)
            topic_files_map[sns_topic].append(s3_ref)

        return dict(topic_files_map)

    def send_notifications_step(self, procedure: ProcedureConfig,
                                transfer_result: SNSMessage) -> List[Dict[str, Any]]:
        """Send SNS notifications to multiple topics based on directory configuration"""
        topic_files_map = self._group_files_by_sns_topic(procedure, transfer_result)
        notification_results = []

        for sns_topic, files in topic_files_map.items():
            try:
                # Create SNS message for this specific topic with its files
                topic_message = SNSMessage(file_Objects=files)

                result = self.sns_notifier.send_notification(sns_topic, topic_message)
                result['sns_topic'] = sns_topic
                result['file_count'] = len(files)
                notification_results.append(result)

                logger.info(f"Sent notification to {sns_topic} for {len(files)} files")

            except Exception as e:
                error_result = {
                    "status": "error",
                    "sns_topic": sns_topic,
                    "file_count": len(files),
                    "error": str(e)
                }
                notification_results.append(error_result)
                logger.error(f"Failed to send notification to {sns_topic}: {str(e)}")

        return notification_results

    def process(self, procedure: ProcedureConfig) -> dict:
        try:
            procedure_result = self.execute_procedure_step(procedure)
            transfer_result = self.transfer_files_step(procedure)
            notification_results = self.send_notifications_step(procedure, transfer_result)

            return create_response(HTTP_STATUS['OK'], {
                "procedure_execution": procedure_result,
                "file_transfer": transfer_result,
                "notifications": notification_results
            })
        except (ProcedureExecutionError, FileTransferError) as e:
            logger.error(f"Error processing procedure {procedure.name}: {str(e)}")
            raise HubWorkflowError(str(e))
        except Exception as e:
            logger.error(f"Unexpected error in procedure {procedure.name}: {str(e)}")
            raise HubWorkflowError(f"Unexpected workflow error: {str(e)}")


@logger.inject_lambda_context
def lambda_handler(event: dict, context: LambdaContext) -> dict:
    try:
        config = HubFunctionConfig.from_env()
        logger.info("Environment variables validated")
        workflow = HubFunctionWorkflow(config)
        results = [workflow.process(procedure) for procedure in config.procedures.values()]
        return results[-1]  # Return the last result for backward compatibility
    except ValueError as e:
        logger.exception("Environment variables not defined")
        return create_response(HTTP_STATUS['VALIDATION_ERROR'], {"message": str(e)})
    except HubWorkflowError as e:
        logger.exception("HUB Workflow execution error")
        return create_response(
            HTTP_STATUS['ERROR'],
            {"message": str(e)}
        )
    except Exception as e:
        logger.exception("Error in lambda execution")
        return create_response(HTTP_STATUS['INTERNAL_ERROR'], {"message": str(e)})
