import json
import boto3
from aws_lambda_powertools import Logger

from utils.sns_message import SNSMessage

logger = Logger(service="sns-handler")


class SNSNotifier:
    def __init__(self, region_name: str = "eu-west-2"):
        self.sns_client = boto3.client('sns',  region_name)

    def send_notification(self, topic_arn: str, message: SNSMessage) -> dict:
        try:
            response = self.sns_client.publish(
                TopicArn=topic_arn,
                Message=json.dumps(message)
            )
            return {"status": "success", "message_id": response['MessageId']}

        except Exception as e:
            logger.exception(f"Error sending SNS notification, {str(e)}")
            raise
