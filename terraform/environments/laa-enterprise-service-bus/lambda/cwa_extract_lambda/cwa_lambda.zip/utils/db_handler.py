import os
import cx_Oracle
from aws_lambda_powertools import Logger

from utils.models import OracleDBSettings, HubFunctionConfig, ProcedureExecutionError

logger = Logger(service="hub-db-handler")


class DBHandler:
    def __init__(self, config: HubFunctionConfig):
        self.settings = OracleDBSettings.from_secret(config)
        oracle_lib_path = os.environ.get('LD_LIBRARY_PATH')
        # Debug: Check library dependencies after setting LD_LIBRARY_PATH
        logger.info(f"LD_LIBRARY_PATH set to: {oracle_lib_path}")
        try:
            # Initialize Oracle client
            cx_Oracle.init_oracle_client(lib_dir=oracle_lib_path)
            logger.info(f"Oracle client initialized successfully from {oracle_lib_path}")
        except Exception as e:
            logger.error(f"Failed to initialize Oracle client: {str(e)}")
            raise


    def execute_procedure(self, procedure_name: str) -> dict:
        """Execute the Oracle procedure and return results"""

        connection = None
        cursor = None

        try:
            connection = cx_Oracle.connect(self.settings.username, self.settings.password, self.settings.host)
            cursor = connection.cursor()

            # Declare variables for OUT parameters
            v_status = cursor.var(cx_Oracle.STRING)
            v_message = cursor.var(cx_Oracle.STRING)

            # Call the procedure
            cursor.callproc(procedure_name, [v_status, v_message])

            # Get the output values
            status_value = v_status.getvalue()
            message_value = v_message.getvalue()

            result = {"status": status_value, "message": message_value,
                      "procedure_name": procedure_name}

            # Check status and log accordingly
            if status_value == "1":
                logger.info(f"Procedure {procedure_name} executed successfully. Message: {message_value}")
                result["success"] = True
            else:
                logger.error(f"Procedure {procedure_name} failed with status: {status_value}. "
                             f"Message: {message_value}")
                result["success"] = False
                raise ProcedureExecutionError(
                    f"Procedure {procedure_name} failed: Status={status_value}, Message={message_value}")

            return result

        except cx_Oracle.Error as e:
            logger.error(f"Oracle database error while executing {procedure_name}: {str(e)}")
            raise ProcedureExecutionError(f"Database error in {procedure_name}: {str(e)}")
        except Exception as e:
            logger.error(f"Unexpected error while executing {procedure_name}: {str(e)}")
            raise ProcedureExecutionError(f"Unexpected error in {procedure_name}: {str(e)}")
        finally:
            if cursor:
                try:
                    cursor.close()
                except Exception as e:
                    logger.warning(f"Error closing cursor: {str(e)}")
            if connection:
                try:
                    connection.close()
                except Exception as e:
                    logger.warning(f"Error closing connection: {str(e)}")
