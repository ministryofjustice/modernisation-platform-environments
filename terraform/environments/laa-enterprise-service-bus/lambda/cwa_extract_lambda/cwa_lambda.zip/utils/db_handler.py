import cx_Oracle
from aws_lambda_powertools import Logger
from utils.models import OracleDBSettings, HubFunctionConfig

logger = Logger(service="hub-db-handler")


class DBHandler:
    def __init__(self, config: HubFunctionConfig):
        self.settings = OracleDBSettings.from_secret(config)

    def execute_procedure(self, procedure_name: str) -> dict:
        try:
            with cx_Oracle.connect(
                    user=self.settings.username,
                    password=self.settings.password,
                    dsn=f"{self.settings.host}:{self.settings.port}/{self.settings.db_name}"
            ) as connection:
                cursor = connection.cursor()
                cursor.callproc(procedure_name)
                return {"status": "success", "procedure": procedure_name}

        except Exception as e:
            logger.exception(f"Error executing procedure: {str(e)}")
            raise
