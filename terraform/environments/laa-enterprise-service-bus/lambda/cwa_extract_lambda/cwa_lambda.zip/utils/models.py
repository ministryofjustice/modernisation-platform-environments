from dataclasses import dataclass
from utils.secrets_utils import SecretsUtil
from utils.provider_config import HubFunctionConfig


class HubWorkflowError(Exception):
    """Base exception for workflow errors"""
    pass


class ProcedureExecutionError(HubWorkflowError):
    """Raised when procedure execution fails"""
    pass


class FileTransferError(HubWorkflowError):
    """Raised when file transfer fails"""
    pass


@dataclass
class OracleDBSettings:
    username: str
    password: str
    host: str

    @classmethod
    def from_secret(cls, config: HubFunctionConfig) -> 'OracleDBSettings':
        """
        Creates OracleDBSettings instance from AWS Secrets Manager.

        Returns:
            OracleDBSettings: Instance populated with database settings
        """

        secret = SecretsUtil.get_secret(config.db_secret_name)
        return OracleDBSettings(
            username=secret.get('Username'),
            password=secret.get('Password'),
            host=secret.get('Host')
        )
