import json
import os
from dataclasses import dataclass
from typing import Dict, List
from utils.db_secrets import DBSecretsUtil


@dataclass
class ProcedureConfig:
    name: str
    files: List[str]
    source_dir: str


@dataclass
class HubFunctionConfig:
    """
    Represents the configuration for a hub function.

    This class is designed to hold the configuration required for managing hub functions,
    which includes mapping procedures, AWS settings like target bucket, SNS topic,
    database secrets, and the region.

    :ivar procedures: A dictionary where each key is the name of a procedure and the
        value is its corresponding `ProcedureConfig`. Defines the procedures to be executed.
    :type procedures: Dict[str, ProcedureConfig]
    :ivar target_bucket: The name of the AWS S3 bucket where results or intermediary data
        will be stored.
    :type target_bucket: str
    :ivar sns_topic: The Amazon SNS topic used for notifications or alerts.
    :type sns_topic: str
    :ivar db_secret_name: The name of the secret in AWS Secrets Manager that holds the
        database credentials.
    :type db_secret_name: str
    :ivar aws_region: The AWS region where resources are located.
    :type aws_region: str
    """
    procedures: Dict[str, ProcedureConfig]
    target_bucket: str
    sns_topic: str
    db_secret_name: str
    aws_region: str

    @classmethod
    def from_env(cls) -> 'HubFunctionConfig':
        procedures_config = os.environ.get('PROCEDURES_CONFIG')

        required_vars = [
            'PROCEDURES_CONFIG',
            'TARGET_BUCKET',
            'SNS_TOPIC',
            'DB_SECRET_NAME',
            'AWS_REGION'
        ]

        missing_vars = [var for var in required_vars if var not in os.environ]

        if missing_vars:
            raise ValueError(
                f"Missing required environment variables: {', '.join(missing_vars)}"
            )
        try:
            config_dict = json.loads(procedures_config)
            procedures = {}
            for proc_name, config in config_dict.items():
                procedures[proc_name] = ProcedureConfig(
                    name=proc_name,
                    files=config['files'],
                    source_dir=config['source_dir']
                )
        except (json.JSONDecodeError, KeyError) as e:
            raise ValueError(f"Invalid PROCEDURES_CONFIG format: {str(e)}")
        return cls(
            procedures=procedures,
            target_bucket=os.environ['TARGET_BUCKET'],
            sns_topic=os.environ['SNS_TOPIC'],
            db_secret_name=os.environ['DB_SECRET_NAME'],
            aws_region=os.environ['AWS_REGION']
        )


class HubWorkflowError(Exception):
    """Base exception for workflow errors"""
    pass


class ProcedureExecutionError(HubWorkflowError):
    """Raised when procedure execution fails"""
    pass


class FileTransferError(HubWorkflowError):
    """Raised when file transfer fails"""
    pass


@dataclass
class OracleDBSettings:
    username: str
    password: str
    host: str
    db_name: str
    port: int

    @classmethod
    def from_secret(cls, config: HubFunctionConfig) -> 'OracleDBSettings':
        """
        Creates OracleDBSettings instance from AWS Secrets Manager.

        Returns:
            OracleDBSettings: Instance populated with database settings
        """

        secrets_util = DBSecretsUtil(config.aws_region)
        secret = secrets_util.get_secret(config.db_secret_name)
        return OracleDBSettings(
            username=secret.get('username'),
            password=secret.get('password'),
            host=secret.get('host'),
            port=int(secret.get('port', 1521)),
            db_name=secret.get('db_name')
        )
