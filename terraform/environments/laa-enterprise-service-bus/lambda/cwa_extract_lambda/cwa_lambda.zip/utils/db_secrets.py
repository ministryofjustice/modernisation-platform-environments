import boto3
import json
import logging
from typing import Dict, Any


class DBSecretsUtil:
    def __init__(self, region_name: str = "eu-west-2"):
        self.region_name = region_name
        self.logger = logging.getLogger(__name__)
        self._session = boto3.session.Session()
        self._client = self._session.client(
            service_name='secretsmanager',
            region_name=self.region_name
        )

    def get_secret(self, secret_name: str) -> Dict[str, Any]:
        """
        Retrieve secret from AWS Secrets Manager
        Args:
            secret_name: Name of the secret in AWS Secrets Manager
        Returns:
            Dict containing the secret values
        """
        try:
            get_secret_value_response = self._client.get_secret_value(
                SecretId=secret_name
            )
            return json.loads(get_secret_value_response['SecretString'])
        except Exception as e:
            self.logger.error(f"Error retrieving secret '{secret_name}': {str(e)}")
            raise
