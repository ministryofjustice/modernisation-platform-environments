import boto3
import json
from aws_lambda_powertools import Logger
from botocore.config import Config
from typing import Dict, Any
from botocore.exceptions import ClientError


logger = Logger(service="secrets-util", level="DEBUG")


class SecretsUtil:

    @staticmethod
    def get_secret(secret_name: str, region_name: str = "eu-west-2") -> Dict[str, Any]:
        try:
            logger.info(f"Retrieving secret '{secret_name}'")
            # Configure boto3 with timeouts and retries
            config = Config(
                connect_timeout=5,  # connection timeout
                read_timeout=5,     # read timeout
                retries={'max_attempts': 3}  # retry 3 times
            )

            session = boto3.session.Session()
            client = session.client(
                service_name='secretsmanager',endpoint_url="https://secretsmanager.eu-west-2.amazonaws.com",
                region_name=region_name,
                config=config
            )
            logger.info(f"Trying to retrieve secret '{secret_name}' after creating client")


            get_secret_value_response = client.get_secret_value(
                SecretId=secret_name
            )
            logger.info(f"Successfully retrieved secret '{secret_name}': {get_secret_value_response}")
            return json.loads(get_secret_value_response['SecretString'])
        except ClientError as e:
            error_code = e.response['Error']['Code']
            if error_code == 'DecryptionFailureException':
                logger.error(f"Secrets Manager cannot decrypt the protected secret text: {str(e)}")
            elif error_code == 'InternalServiceErrorException':
                logger.error(f"Internal Secrets Manager error occurred: {str(e)}")
            elif error_code == 'InvalidParameterException':
                logger.error(f"Invalid parameter provided to Secrets Manager: {str(e)}")
            elif error_code == 'InvalidRequestException':
                logger.error(f"Invalid request made to Secrets Manager: {str(e)}")
            elif error_code == 'ResourceNotFoundException':
                logger.error(f"Secret {secret_name} not found: {str(e)}")
            raise
        except Exception as e:
            logger.error(f"Error retrieving secret '{secret_name}': {str(e)}")
            raise
