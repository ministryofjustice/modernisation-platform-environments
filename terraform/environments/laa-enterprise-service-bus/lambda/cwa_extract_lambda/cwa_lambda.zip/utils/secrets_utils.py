import boto3
import json
from aws_lambda_powertools import Logger
from typing import Dict, Any

logger = Logger(service="secrets-util")


class SecretsUtil:

    @staticmethod
    def get_secret(secret_name: str, region_name: str = "eu-west-2") -> Dict[str, Any]:
        try:
            session = boto3.session.Session()
            client = session.client(
                service_name='secretsmanager',
                region_name=region_name
            )

            get_secret_value_response = client.get_secret_value(
                SecretId=secret_name
            )
            logger.info(f"Successfully retrieved secret '{secret_name}': {get_secret_value_response}")
            return json.loads(get_secret_value_response['SecretString'])
        except Exception as e:
            logger.error(f"Error retrieving secret '{secret_name}': {str(e)}")
            raise
