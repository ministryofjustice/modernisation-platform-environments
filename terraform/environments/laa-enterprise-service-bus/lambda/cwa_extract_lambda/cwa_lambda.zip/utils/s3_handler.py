import os
from datetime import datetime
from typing import Dict, List

import boto3
from aws_lambda_powertools import Logger

from utils.models import FileTransferError
from utils.provider_config import ProcedureConfig
from common.sns_message import S3RefObject, SNSMessage

logger = Logger(service="s3-handler")


class S3Handler:
    S3_ROOT_PREFIX = "HUB20"

    def __init__(self):
        self.s3_client = boto3.client('s3')
        self.timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')

    def upload_file_to_s3(self, file_path: str, bucket: str, object_key: str) -> Dict[str, str]:
        try:
            self.s3_client.upload_file(file_path, bucket, object_key)
            return {"status": "success", "s3_uri": f"s3://{bucket}/{object_key}"}
        except Exception as e:
            logger.exception(f"Error uploading file {object_key} to S3: {str(e)}")
            return {"status": "error", "s3_uri": ""}

    def transfer_files_to_s3(self, config: ProcedureConfig, target_bucket: str) -> SNSMessage:
        transfer_results: List[S3RefObject] = []

        # Iterate through each source directory and its files
        for source_dir, dir_config in config.files_dirs.items():
            if not os.path.exists(source_dir):
                logger.warning(f"Source directory {source_dir} does not exist, skipping")
                continue

            # Get the base directory name for S3 path
            dir_name = os.path.basename(source_dir.rstrip('/'))

            # Process each file in the current directory
            for file_name in dir_config.files:
                result = self._process_single_file(
                    file_name=file_name,
                    source_dir=source_dir,
                    dir_name=dir_name,
                    target_bucket=target_bucket
                )
                transfer_results.append(result)

        if any(result.status == "error" for result in transfer_results):
            raise FileTransferError("Some file transfers failed")

        return SNSMessage(file_Objects=transfer_results, folder_name=self.timestamp)

    def _process_single_file(self, file_name: str, source_dir: str,
                             dir_name: str, target_bucket: str) -> S3RefObject:
        """Process a single file transfer to S3."""
        try:
            source_path = os.path.join(source_dir, file_name)

            # Create S3 key with structure: HUB20/{dir_name}/{timestamp}/{file_name}
            s3_key = f"{self.S3_ROOT_PREFIX}/{dir_name}/{self.timestamp}/{file_name}"

            result = self.upload_file_to_s3(
                file_path=source_path,
                bucket=target_bucket,
                object_key=s3_key
            )

            if result["status"] == "success":
                logger.info(
                    f"File {file_name} transferred to S3 bucket {target_bucket} "
                    f"with key {s3_key}"
                )

            return S3RefObject(
                status=result["status"],
                s3_uri=result["s3_uri"],
                file_name=file_name
            )

        except Exception as e:
            logger.error(f"Failed to transfer file {file_name} from {source_dir}: {str(e)}")
            return S3RefObject(
                status="error",
                s3_uri="",
                file_name=file_name
            )
