import os
from typing import Dict, List

import boto3
from aws_lambda_powertools import Logger

from utils.models import ProcedureConfig, FileTransferError
from utils.sns_message import S3RefObject, SNSMessage

logger = Logger(service="s3-handler")


class S3Handler:
    def __init__(self):
        self.s3_client = boto3.client('s3')

    def upload_file_to_s3(self, file_path: str, bucket: str, object_key: str) -> Dict[str, any]:
        try:
            # Upload the file
            self.s3_client.upload_file(file_path, bucket, object_key)

            # Get the S3 object reference
            return {"status": "success", "s3_uri": f"s3://{bucket}/{object_key}"}

        except Exception as e:
            logger.exception(f"Error uploading file {object_key} to S3: {str(e)}")
            return {"status": "error", "s3_uri": ""}

    def transfer_files_to_s3(self, config: ProcedureConfig, target_bucket: str) -> SNSMessage:
        transfer_results: List[S3RefObject] = []
        for file_name in config.files:
            source_path = os.path.join(config.source_dir, file_name)
            s3_key = f"{config.name}/{file_name}"
            try:
                result = self.upload_file_to_s3(
                    file_path=source_path,
                    bucket=target_bucket,
                    object_key=s3_key
                )
                logger.info(
                    f"File {file_name} transferred to S3 bucket {target_bucket} with key {s3_key}")
                transfer_results.append(
                    S3RefObject(
                        status=result["status"],
                        s3_uri=result["s3_uri"],
                        file_name=file_name
                    )
                )
            except Exception as e:
                logger.error(f"Failed to transfer file {file_name}: {str(e)}")
                transfer_results.append(
                    S3RefObject(
                        status="error",
                        s3_uri="",
                        file_name=file_name
                    )
                )
        if any(result.status == "error" for result in transfer_results):
            raise FileTransferError("File transfers failed")

        return SNSMessage(file_Objects=transfer_results)
