import os
import cx_Oracle
from aws_lambda_powertools import Logger

from common.db_client_loader import OracleClientLoader
from common.db_settings import OracleDBSettings
from cwa_extract.provider_config import HubFunctionConfig
from common.errors import ProcedureExecutionError

logger = Logger(service="hub-db-handler", level="DEBUG")


class DBHandler:
    def __init__(self, config: HubFunctionConfig):
        self.settings = OracleDBSettings.from_secret(config.db_secret_name)
        oracle_lib_path = os.environ.get('LD_LIBRARY_PATH')
        OracleClientLoader.initialize_client(oracle_lib_path)

    def execute_procedure(self, procedure_name: str) -> dict:
        """Execute the Oracle procedure and return results"""
        connection = None
        cursor = None

        logger.debug(f"db details: user={self.settings.username}, dsn={self.settings.dsn}")
        try:
            connection = cx_Oracle.connect(user=self.settings.username, password=self.settings.password,
                                           dsn=self.settings.dsn)
            logger.debug("DB Connection established")

            cursor = connection.cursor()

            # Declare variables for OUT parameters
            p_status = cursor.var(cx_Oracle.NUMBER)
            p_message = cursor.var(cx_Oracle.STRING)

            # Call the procedure
            cursor.callproc(procedure_name, [p_status, p_message])
            logger.debug("Procedure execution finished")

            # Get the output values
            status_value = p_status.getvalue()
            message_value = p_message.getvalue()

            result = {"status": status_value, "message": message_value,
                      "procedure_name": procedure_name}

            # Check status and log accordingly
            if status_value == 0.0:
                logger.info(f"Procedure {procedure_name} executed successfully. Message: {message_value}")
                result["success"] = True
            else:
                logger.error(f"Procedure {procedure_name} failed with status: {status_value}. "
                             f"Message: {message_value}")
                result["success"] = False
                raise ProcedureExecutionError(
                    f"Procedure {procedure_name} failed: Status={status_value}, Message={message_value}")

            return result

        except cx_Oracle.Error as e:
            logger.error(f"Oracle database error while executing {procedure_name}: {str(e)}")
            raise ProcedureExecutionError(f"Database error in {procedure_name}: {str(e)}")
        except Exception as e:
            logger.error(f"Unexpected error while executing {procedure_name}: {str(e)}")
            raise ProcedureExecutionError(f"Unexpected error in {procedure_name}: {str(e)}")
        finally:
            if cursor:
                try:
                    cursor.close()
                except Exception as e:
                    logger.warning(f"Error closing cursor: {str(e)}")
            if connection:
                try:
                    connection.close()
                except Exception as e:
                    logger.warning(f"Error closing connection: {str(e)}")
