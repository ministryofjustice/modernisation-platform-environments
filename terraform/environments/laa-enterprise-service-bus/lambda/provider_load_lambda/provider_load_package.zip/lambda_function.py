import json
from typing import Dict, Any, List

from common.constants import get_logger_obj, get_metrics_obj, ENVIRONMENT, safe_add_dimension, HTTP_STATUS
from common.errors import LoadProcedureExecutionError
from load_procedure.env_validator import LoadConfig
from load_procedure.load_constants import SERVICE_NAME, NAMESPACE
from load_procedure.load_process import LoadProcessor
from aws_lambda_powertools.metrics import MetricUnit


logger = get_logger_obj(SERVICE_NAME)
metrics = get_metrics_obj(SERVICE_NAME, NAMESPACE)


@logger.inject_lambda_context()
@metrics.log_metrics
def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    results = []
    folder_name = None

    try:
        # Validate and get environment variables using reusable validator
        load_config = LoadConfig.from_env(logger)
        logger.info(f"Processing SQS event with {len(event.get('Records', []))} records")

        processor = LoadProcessor(load_config, logger)

        # Process each SQS record and collect results
        for i, record in enumerate(event.get('Records', [])):
            message_id = record.get('messageId', 'unknown')
            sns_message = processor.parse_sns_message_from_sqs(record)
            logger.info(f"Processing SQS record: {record.get('messageId', 'unknown')}")
            # Extract folder name
            folder_name = sns_message.folder_name
            success = processor.process_sqs_record(folder_name)
            if not success:
                raise LoadProcedureExecutionError(f"Failed to process SQS message {message_id}")
            results.append({
                'record_index': i,
                'success': success,
                'message_id': message_id
            })
            metrics.add_dimension(name="environment", value=ENVIRONMENT)
            metrics.add_dimension(name="timestamp", value=folder_name)
            safe_add_dimension(metrics, name="status", value='200')
            safe_add_dimension(metrics, name="message", value="Successfully executed load lambda")
            metrics.add_metric(name="InvocationSuccessCount", unit=MetricUnit.Count, value=1)
        return create_response(results)
    except ValueError as e:
        logger.error(f"Lambda execution failed with validation error: {str(e)}")
        metrics.add_dimension(name="environment", value=ENVIRONMENT)
        metrics.add_dimension(name="timestamp", value=folder_name)
        safe_add_dimension(metrics, name="status", value=f"{HTTP_STATUS['VALIDATION_ERROR']}")
        safe_add_dimension(metrics, name="message", value=str(e))
        metrics.add_metric(name="InvocationFailureCount", unit=MetricUnit.Count, value=1)
        raise ValueError(str(e))
    except LoadProcedureExecutionError as e:
        logger.error(f"Lambda execution failed while invoking load procedure: {str(e)}")
        metrics.add_dimension(name="environment", value=ENVIRONMENT)
        metrics.add_dimension(name="timestamp", value=folder_name)
        safe_add_dimension(metrics, name="status", value=f"{HTTP_STATUS['INTERNAL_ERROR']}")
        safe_add_dimension(metrics, name="message", value=str(e))
        metrics.add_metric(name="InvocationFailureCount", unit=MetricUnit.Count, value=1)
        raise LoadProcedureExecutionError(str(e))
    except Exception as e:
        logger.error(f"Lambda execution failed: {str(e)}")
        metrics.add_dimension(name="environment", value=ENVIRONMENT)
        metrics.add_dimension(name="timestamp", value=folder_name)
        safe_add_dimension(metrics, name="status", value=f"{HTTP_STATUS['INTERNAL_ERROR']}")
        safe_add_dimension(metrics, name="message", value=str(e))
        metrics.add_metric(name="InvocationFailureCount", unit=MetricUnit.Count, value=1)
        raise Exception(str(e))


def create_response(results: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Create standardized Lambda response."""
    successful_count = sum(1 for result in results if result.get('success', False))
    total_count = len(results)

    response = {
        'statusCode': 200 if successful_count == total_count else 207,
        'body': json.dumps({
            'processed_records': total_count,
            'successful_records': successful_count,
            'failed_records': total_count - successful_count,
            'results': results
        })
    }

    logger.info(f"Processing complete: {successful_count}/{total_count} records successful")
    return response
