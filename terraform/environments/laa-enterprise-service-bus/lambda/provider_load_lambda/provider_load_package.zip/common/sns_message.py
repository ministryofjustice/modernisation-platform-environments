from dataclasses import dataclass


@dataclass
class SNSMessage:
    folder_name: str

    def to_dict(self):
        return {
            "folder_name": self.folder_name
        }
