from dataclasses import dataclass
from common.secrets_utils import SecretsUtil
from aws_lambda_powertools import Logger


@dataclass
class OracleDBSettings:
    username: str
    password: str
    dsn: str

    @classmethod
    def from_secret(cls, secret: str, region_name: str = "eu-west-2", logger: Logger = None) -> 'OracleDBSettings':
        """
        Creates OracleDBSettings instance from AWS Secrets Manager.

        Returns:
            OracleDBSettings: Instance populated with database settings
        """

        secret = SecretsUtil.get_secret(secret, region_name, logger)
        return OracleDBSettings(
            username=secret.get('Username'),
            password=secret.get('Password'),
            dsn=secret.get('DSN')
        )
