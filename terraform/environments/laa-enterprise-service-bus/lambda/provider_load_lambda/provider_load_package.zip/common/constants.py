import json
import os
from typing import Dict, Any
from aws_lambda_powertools import Logger, Metrics


LOG_LEVEL = os.getenv("LOG_LEVEL", "DEBUG")
SERVICE_NAME = os.getenv("SERVICE_NAME", "hub20-lambda")
NAMESPACE = os.getenv("NAMESPACE", "HUB20Process")
ENVIRONMENT = os.getenv("ENVIRONMENT", "development")

FILE_GROUPS = [
    {
        'filenames': [
            'ccms_vendor_sites.json',
            'ccms_vendors.json',
            'ccms_vendor_contacts.json',
            'xxlsc_vendor_sites.json',
            'provider_sites.json'
            ],
        'directory': 'provider'
        },
    {
        'filenames': [
            'bank_acct.json',
            'bank_acct_uses.json',
            'bank_branch.json'
            ],
        'directory': 'provider_banks'
        }
    ]

FILE_NAMES = [
    {"filename": "ccms_vendor_sites.json"},
    {"filename": "ccms_vendors.json"},
    {"filename": "ccms_vendor_contacts.json"},
    {"filename": "xxlsc_vendor_sites.json"},
    {"filename": "provider_sites.json"},
    {"filename": "bank_acct.json"},
    {"filename": "bank_acct_uses.json"},
    {"filename": "bank_branch.json"}
    ]
CONTENT_TYPE_JSON = "application/json"

HTTP_STATUS = {
    'OK': 200,
    'ERROR': 400,
    'VALIDATION_ERROR': 422,
    'INTERNAL_ERROR': 500
    }


def create_response(status_code: int, body: Dict[str, Any]) -> Dict[str, Any]:
    """Create a standardized HTTP response"""
    return {
        "statusCode": status_code,
        "body": body,
        "headers": {"Content-Type": CONTENT_TYPE_JSON}
        }


def create_response_str(status_code: int, body: Dict[str, Any]) -> Dict[str, Any]:
    """Create a standardized HTTP response"""
    return {
        "statusCode": status_code,
        "body": json.dumps(body),
        "headers": {"Content-Type": CONTENT_TYPE_JSON}
        }


def get_logger_obj(service_name: str = SERVICE_NAME) -> Logger:
    return Logger(service=service_name, level=LOG_LEVEL)


def get_metrics_obj(service_name: str = SERVICE_NAME, namespace: str = NAMESPACE) -> Metrics:
    return Metrics(namespace=namespace, service=service_name)
