import os


SERVICE_NAME = os.getenv("SERVICE_NAME", "load-lambda-service")
NAMESPACE = os.getenv("NAMESPACE", "LoadDataProcess")
