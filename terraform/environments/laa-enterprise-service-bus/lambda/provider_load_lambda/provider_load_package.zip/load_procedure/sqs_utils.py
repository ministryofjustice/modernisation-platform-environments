import boto3
import time
import os
from typing import Any, Dict

from common.constants import get_logger_obj, get_metrics_obj
from load_procedure.load_constants import SERVICE_NAME, NAMESPACE

logger = get_logger_obj(SERVICE_NAME)
metrics = get_metrics_obj(SERVICE_NAME, NAMESPACE)

AWS_REGION = os.environ.get("AWS_REGION", "eu-west-2")


sqs = boto3.client('sqs', region_name=AWS_REGION)


def dlq_not_empty(provider_dlq: str) -> bool:
    "Check if DLQ has messages"
    response = sqs.get_queue_attributes(QueueUrl=provider_dlq, AttributeNames=['ApproximateNumberOfMessages'])
    num_messages = int(response['Attributes'].get('ApproximateNumberOfMessages'))
    return num_messages > 0


def is_old_message(record: Dict[str, Any], max_age: int = 13) -> bool:
    "Check if message is older than max_age."
    attrs = record.get('Attributes', {})
    sent_timestamp = int(attrs.get('SentTimestamp', 0))
    message_age_seconds = (time.time() * 1000 - sent_timestamp) / 1000
    return message_age_seconds > max_age * 86400


def send_to_dlq(record: Dict[str, Any], provider_dlq: str, provider_queue: str):
    """Send message to DLQ and remove from main queue"""
    message_group_id = record.get("MessageAttributes",
                                  {}).get("MessageGroupId",
                                          {}).get("StringValue",
                                                  record.get("MessageId", "default-group"))
    message_deduplication_id = record.get("MessageId", str(time.time()))
    sqs.send_message(QueueUrl=provider_dlq,
                     MessageBody=record['Body'],
                     MessageAttributes=record.get('MessageAttributes', {}),
                     MessageGroupId=message_group_id,
                     MessageDeduplicationId=message_deduplication_id)
    try:
        sqs.delete_message(QueueUrl=provider_queue, ReceiptHandle=record['ReceiptHandle'])
    except Exception:
        logger.warning(f"Failed to delete message: {record['Body']}")
