import boto3
import time
import os
from typing import Any, Dict, List

from aws_lambda_powertools.metrics import MetricUnit
from common.constants import get_logger_obj, get_metrics_obj, ENVIRONMENT
from load_procedure.load_constants import SERVICE_NAME, NAMESPACE

logger = get_logger_obj(SERVICE_NAME)
metrics = get_metrics_obj(SERVICE_NAME, NAMESPACE)

AWS_REGION = os.environ.get("AWS_REGION", "eu-west-2")


sqs = boto3.client('sqs', region_name=AWS_REGION)


def fetch_messages(provider_dlq: str, provider_queue: str) -> (List[Dict[str, Any]], str):
    """Pull main queue messages, send to DLQ if messages older than 13 days.
        Check if messages in DLQ, returns that as sorted queue to load lambda if so.
        If DLQ empty, we return main queue to load lambda instead."""
    main_response = sqs.receive_message(
        QueueUrl=provider_queue,
        MaxNumberOfMessages=10,
        WaitTimeSeconds=0,
        MessageAttributeNames=['All'],
        AttributeNames=['All']
    )
    main_messages = main_response.get("Messages", [])
    for record in main_messages:
        if is_old_message(record):
            send_to_dlq(record, provider_dlq, provider_queue)

    dlq_messages = []
    while True:
        dlq_response = sqs.receive_message(
            QueueUrl=provider_dlq,
            MaxNumberOfMessages=10,
            WaitTimeSeconds=10,
            MessageAttributeNames=['All'],
            AttributeNames=['All']
        )
        batch = dlq_response.get("Messages", [])
        if not batch:
            break
        dlq_messages.extend(batch)
    if dlq_messages:
        dlq_messages.sort(key=lambda m: int(m["Attributes"]["SentTimestamp"]))
        return dlq_messages, "DLQ"

    return main_messages, "Main Queue"


def is_old_message(record: Dict[str, Any], max_age: int = 13) -> bool:
    "Check if message is older than max_age."
    attrs = record.get('Attributes', {})
    sent_timestamp = int(attrs.get('SentTimestamp', 0))
    message_age_seconds = (time.time() * 1000 - sent_timestamp) / 1000
    return message_age_seconds > max_age * 86400


def send_to_dlq(record: Dict[str, Any], provider_dlq: str, provider_queue: str):
    """Send message to DLQ and remove from main queue"""
    message_id = record['MessageId']
    sqs.send_message(QueueUrl=provider_dlq,
                     MessageBody=record['Body'],
                     MessageAttributes=record.get('MessageAttributes', {}))
    sqs.delete_message(QueueUrl=provider_queue, ReceiptHandle=record['ReceiptHandle'])
    metrics.add_dimension(name="environment", value=ENVIRONMENT)
    metrics.add_metric(name="InvocationFailureCount", unit=MetricUnit.Count, value=1)
    raise Exception(f"Message sent to DLQ as message: {message_id} failed to process for > 13 days.")
