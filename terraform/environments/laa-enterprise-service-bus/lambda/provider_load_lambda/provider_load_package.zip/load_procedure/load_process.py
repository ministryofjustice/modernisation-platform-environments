import json
from typing import Dict, Any

from aws_lambda_powertools import Logger

from common.errors import LoadProcedureExecutionError
from load_procedure.load_db_handler import LoadDBHandler
from common.sns_message import SNSMessage
from load_procedure.env_validator import LoadConfig


class LoadProcessor:

    def __init__(self, load_config: LoadConfig, logger: Logger):
        self.load_config = load_config
        self.logger = logger

    def parse_sns_message_from_sqs(self, sqs_record: Dict[str, Any]) -> SNSMessage:
        """Parse SNS message from SQS record"""
        try:
            # Extract SNS message from SQS record
            sns_data = json.loads(sqs_record['body'])

            # If the message is wrapped in SNS format
            if 'Message' in sns_data:
                message_data = json.loads(sns_data['Message'])
            else:
                message_data = sns_data

            folder = message_data.get('folder_name', '')
            if not folder:
                raise ValueError("No folder name found in SNS message")

            sns_message = SNSMessage(folder_name=folder)

            self.logger.info(f"Parsed SNS message with folder: {sns_message.folder_name}")
            return sns_message

        except Exception as e:
            self.logger.error(f"Failed to parse SNS message from SQS record: {str(e)}")
            raise

    def process_sqs_record(self, record: Dict[str, Any]) -> bool:
        """Process a single SQS record"""
        try:
            self.logger.info(f"Processing SQS record: {record.get('messageId', 'unknown')}")

            # Parse SNS message from SQS record
            sns_message = self.parse_sns_message_from_sqs(record)

            # Extract folder name
            folder_name = sns_message.folder_name
            if not folder_name:
                self.logger.warning("No folder name found in SNS message")
                return False

            self.logger.info(f"Processing folder: {folder_name}")
            load_db_handler = LoadDBHandler(self.load_config, self.logger)
            # Call database procedure
            load_db_handler.execute_procedure(self.load_config.procedure, folder_name)

            return True

        except Exception as e:
            self.logger.error(f"Failed to process SQS record {record.get('messageId', 'unknown')}: {str(e)}")
            raise LoadProcedureExecutionError(e)
