Place Oracle Instant Client 12.2 for Linux files in this directory, e.g. extracted from file: 
`instantclient-basiclite-linux.x64-12.2.0.1.0.zip`

Note also need to create symbolic link afterwards    
`ln -s ./libclntsh.so.12.1 ./libclntsh.so`