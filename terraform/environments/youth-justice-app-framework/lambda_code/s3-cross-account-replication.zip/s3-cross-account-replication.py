import boto3
import urllib
from concurrent.futures import ThreadPoolExecutor

SOURCE_BUCKET = 'redshift-serverless-yjb-reporting'.strip()
TARGET_BUCKET = 'mojap-youth-justice-board'.strip()
TARGET_PREFIX = 'moj_export/'  # Specify the folder prefix here

s3_resource = boto3.resource('s3')
s3_client = boto3.client('s3')

CHUNK_SIZE = 64 * 1024 * 1024  # 64 MB
MAX_THREADS = 5  # Number of parallel threads


def lambda_handler(event, context):
    # Determine if the trigger is from S3 (file uploaded to SOURCE_BUCKET)
    if 'Records' in event and event['Records'][0]['eventSource'] == 'aws:s3':
        # S3 event trigger for files added to SOURCE_BUCKET
        source_bucket = event['Records'][0]['s3']['bucket']['name']
        source_key = urllib.parse.unquote_plus(event['Records'][0]['s3']['object']['key'])

        # Transfer file in chunks
        transfer_file_in_chunks(source_bucket, source_key, TARGET_BUCKET, source_key)
        print(f"Transferred file {source_key} from {SOURCE_BUCKET} to {TARGET_BUCKET} in chunks.")

    else:
        # Scheduled EventBridge trigger to check TARGET_BUCKET for the latest file in TARGET_PREFIX
        target_bucket = s3_resource.Bucket(TARGET_BUCKET)

        # Retrieve all objects in TARGET_BUCKET with the specified prefix
        objects = list(target_bucket.objects.filter(Prefix=TARGET_PREFIX))
        if not objects:
            print(f"No files found in {TARGET_BUCKET}/{TARGET_PREFIX}.")
            return

        # Filter out any "folders" (keys ending in "/")
        files = [obj for obj in objects if not obj.key.endswith('/')]
        if not files:
            print(f"No valid files found in {TARGET_BUCKET}/{TARGET_PREFIX}.")
            return

        # Find the latest modified file within the folder specified by TARGET_PREFIX
        latest_object = max(files, key=lambda obj: obj.last_modified)

        # Transfer the latest object to SOURCE_BUCKET in chunks
        source_key = latest_object.key
        transfer_file_in_chunks(TARGET_BUCKET, source_key, SOURCE_BUCKET, source_key)
        print(f"Transferred latest file {source_key} from {TARGET_BUCKET}/{TARGET_PREFIX} to {SOURCE_BUCKET} in chunks.")

        # Move the object to the "processed/" folder in TARGET_BUCKET
        processed_key = f"processed/{source_key[len(TARGET_PREFIX):]}"

        # Check file size and choose copy method
        head_response = s3_client.head_object(Bucket=TARGET_BUCKET, Key=source_key)
        file_size = head_response['ContentLength']

        if file_size > 5 * 1024 * 1024 * 1024:  # File is larger than 5GB
            transfer_file_in_chunks(TARGET_BUCKET, source_key, TARGET_BUCKET, processed_key)
        else:
            s3_resource.Object(TARGET_BUCKET, processed_key).copy_from(
                CopySource={'Bucket': TARGET_BUCKET, 'Key': source_key},
                ACL='bucket-owner-full-control'
            )
        print(f"Copied {source_key} to {processed_key} in {TARGET_BUCKET}.")

        # Delete only if it’s a file
        if not source_key.endswith('/'):
            s3_resource.Object(TARGET_BUCKET, source_key).delete()
            print(f"Deleted original file {source_key} from {TARGET_BUCKET}")

    print("File transfer operation completed.")


def upload_chunk(part_number, start_byte, end_byte, source_bucket, source_key, target_bucket, target_key, upload_id):
    """
    Upload a single chunk using upload_part_copy.
    """
    print(f"Uploading part {part_number} (bytes {start_byte}-{end_byte})...")
    response = s3_client.upload_part_copy(
        Bucket=target_bucket,
        Key=target_key,
        CopySource={'Bucket': source_bucket, 'Key': source_key},
        CopySourceRange=f"bytes={start_byte}-{end_byte}",
        UploadId=upload_id,
        PartNumber=part_number
    )
    print(f"Part {part_number} uploaded.")
    return {
        'PartNumber': part_number,
        'ETag': response['CopyPartResult']['ETag']
    }


def transfer_file_in_chunks(source_bucket, source_key, target_bucket, target_key):
    """
    Transfers a file from the source bucket to the target bucket in chunks using multipart upload.
    Parallelizes the upload of parts for improved performance.
    """
    # Get the file size from the source bucket
    head_response = s3_client.head_object(Bucket=source_bucket, Key=source_key)
    file_size = head_response['ContentLength']
    print(f"File size: {file_size} bytes")

    # Start a multipart upload in the target bucket
    multipart_upload = s3_client.create_multipart_upload(
        Bucket=target_bucket,
        Key=target_key,
        ACL='bucket-owner-full-control'
    )
    upload_id = multipart_upload['UploadId']
    print(f"Started multipart upload with UploadId: {upload_id}")

    parts = []
    futures = []

    try:
        # Use ThreadPoolExecutor to upload parts in parallel
        with ThreadPoolExecutor(max_workers=MAX_THREADS) as executor:
            part_number = 1
            start_byte = 0

            while start_byte < file_size:
                # Define the byte range for this chunk
                end_byte = min(start_byte + CHUNK_SIZE - 1, file_size - 1)

                # Submit each chunk upload to the executor
                futures.append(executor.submit(
                    upload_chunk, part_number, start_byte, end_byte,
                    source_bucket, source_key, target_bucket, target_key, upload_id
                ))

                # Move to the next chunk
                start_byte += CHUNK_SIZE
                part_number += 1

            # Collect results from futures
            for future in futures:
                parts.append(future.result())

        # Complete the multipart upload
        s3_client.complete_multipart_upload(
            Bucket=target_bucket,
            Key=target_key,
            UploadId=upload_id,
            MultipartUpload={'Parts': parts}
        )
        print(f"Completed multipart upload for {target_key} in {target_bucket}.")

    except Exception as e:
        # Abort the multipart upload in case of failure
        s3_client.abort_multipart_upload(
            Bucket=target_bucket,
            Key=target_key,
            UploadId=upload_id
        )
        print(f"Aborted multipart upload for {target_key} due to error: {e}")
        raise
