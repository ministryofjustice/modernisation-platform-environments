import json
import boto3
import os

client = boto3.client('inspector2')

def lambda_handler(event, context):
    # Read from environment variables
    tag_key = os.environ.get("TAG_KEY", "OS")
    tag_value = os.environ.get("TAG_VALUE", "Linux")

    response = client.create_sbom_export(
        reportFormat='SPDX_2_3',
        resourceFilterCriteria={
            'ec2InstanceTags': [
                {
                    'comparison': 'EQUALS',
                    'key': tag_key,
                    'value': tag_value
                }
            ]
        },
        s3Destination={
            'bucketName': os.environ["S3_BUCKET"],
            'keyPrefix': os.environ.get("S3_PREFIX", "sbom-ec2-exports/"),
            'kmsKeyArn': os.environ["KMS_KEY_ARN"]
        }
    )

    return {
        'statusCode': 200,
        'body': json.dumps(response, default=str)
    }
