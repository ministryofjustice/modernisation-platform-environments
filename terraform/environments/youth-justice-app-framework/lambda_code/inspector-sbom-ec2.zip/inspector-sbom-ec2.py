import json
import boto3
import os
from datetime import datetime

inspector = boto3.client("inspector2")

def lambda_handler(event, context):
    tag_key = os.environ.get("TAG_KEY", "Patch Group")
    tag_value = os.environ.get("TAG_VALUE", "Linux2")

    # Generate date-based prefix
    date_prefix = datetime.utcnow().strftime("%Y-%m-%d")
    s3_prefix = f"{os.environ.get('S3_PREFIX', 'sbom-ec2-exports/')}{date_prefix}/"

    # Kick off SBOM export (async)
    export_resp = inspector.create_sbom_export(
        reportFormat="SPDX_2_3",
        resourceFilterCriteria={
            "ec2InstanceTags": [
                {"comparison": "EQUALS", "key": tag_key, "value": tag_value}
            ]
        },
        s3Destination={
            "bucketName": os.environ["S3_BUCKET"],
            "keyPrefix": s3_prefix,
            "kmsKeyArn": os.environ["KMS_KEY_ARN"],
        },
    )

    export_id = export_resp["reportId"]

    return {
        "statusCode": 200,
        "body": json.dumps(
            {
                "StartedExportId": export_id,
                "S3PrefixUsed": s3_prefix,
            },
            default=str,
        ),
    }

