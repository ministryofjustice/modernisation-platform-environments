import os
from datetime import datetime
from urllib.request import urlopen
EXPECTED = os.environ['expected']  # String expected to be on the page, stored in the expected environment variable

def collect_sites():
    SITES=[]
    for k, v in os.environ.items():
        if 'site_' in k:
            #print(f'{k}={v}')
            SITES.append(v)  # URL of the site to check, stored in the site environment variable
    return SITES

def validate(res):
    '''Return False to trigger the canary

    Currently this simply checks whether the EXPECTED string is present.
    However, you could modify this to perform any number of arbitrary
    checks on the contents of SITE.
    '''
    return EXPECTED in res


def lambda_handler(event, context):
    '''
    print('Checking {} at {}...'.format(SITE, event['time']))
   '''
    SITES = collect_sites()
    #print('Updated SITES list: ', SITES)
    for SITE in SITES:
        try:
            print(str(urlopen(SITE).read()))
            if not validate(str(urlopen(SITE).read())):
                raise Exception('Validation failed')
        except Exception as e:
            print('Health endpoint DOWN for {}'.format(SITE))
            print(e)
            #raise
        else:
            print('Health endpoint UP for {}'.format(SITE))
            '''
            return event['time']
            '''
            '''
        finally:
            print('Check complete at {}'.format(str(datetime.now())))
            '''
    
        #else: