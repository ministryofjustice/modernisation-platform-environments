import os
from datetime import datetime
import urllib.request

#Constants
# standard url for all app health checks, uses private lb and header service-health
URL = "http://private-lb.development.yjaf:8080/actuator/health"
EXPECTED = os.environ["expected"]  # String expected in response taken from lambda environment variable

#create a list of services from environment variables that start with "site_"
def collect_services():
    """Return a list of service header values from env vars site_1, site_2, etc."""
    services = []
    for k, v in os.environ.items():
        if k.startswith("site_"):
            services.append(v.strip())
    return services #here services is a list of values for the service-health header
#the private lb will then use that header to route the request to the correct service


#validate if the value of expected is in the response text from the health endpoint
def validate(response_text):
    """Return True if EXPECTED string is found in response"""
    return EXPECTED in response_text

def lambda_handler(event, context):
    services = collect_services()

    for service in services:
        try:
            req = urllib.request.Request(URL) #create the url with urllib
            req.add_header("service-health", service) #add the header

            with urllib.request.urlopen(req) as res: #hit the url
                body = res.read().decode() #read response body
                print(f"[{service}] Response: {body}")

                if not validate(body): #if expected string not found raise an exception
                    raise Exception("Validation failed: expected string not found")

        except Exception as e:
            print(f"[{service}] Health endpoint DOWN") #show it is DOWN for datadog to read
            print(e)
        else:
            print(f"[{service}] Health endpoint UP")

    print(f"Health checks complete at {datetime.utcnow().isoformat()} UTC")
