import boto3
import xml.etree.ElementTree as ET
import os

# Initialize boto3 clients for CloudWatch Logs and Secrets Manager
logs_client = boto3.client('logs')
secrets_client = boto3.client('secretsmanager')

# Define the log group name and log streams from environment variables
log_group_name = os.environ['LOG_GROUP_NAME']
log_streams = os.environ['LOG_STREAMS'].split(',')
secret_name = os.environ['SECRET_NAME']

def get_latest_log_event(log_group_name, log_stream_name):
    response = logs_client.get_log_events(
        logGroupName=log_group_name,
        logStreamName=log_stream_name,
        limit=1,  # Fetch the latest log event
        startFromHead=False
    )
    return response['events'][0]['message'] if response['events'] else None

def extract_dc_name(log_event_message):
    # Parse the XML log event
    root = ET.fromstring(log_event_message)
    computer_element = root.find(".//{http://schemas.microsoft.com/win/2004/08/events/event}Computer")
    return computer_element.text if computer_element is not None else None

def update_secret(dc_names):
    # Retrieve the existing secret
    response = secrets_client.get_secret_value(SecretId=secret_name)
    secret_string = response['SecretString']
    
    # Assuming the secret is a string containing the DC names separated by commas
    existing_dc_names = secret_string.split(',')

    # Replace the old DC names with the new ones
    for i, stream in enumerate(log_streams):
        if stream in dc_names:
            existing_dc_names[i] = f"ldaps://{dc_names[stream]}:636"

    # Update the secret
    updated_secret_string = ','.join(existing_dc_names)
    secrets_client.update_secret(
        SecretId=secret_name,
        SecretString=updated_secret_string
    )

def lambda_handler(event, context):
    dc_names = {}
    for stream in log_streams:
        log_event_message = get_latest_log_event(log_group_name, stream)
        if log_event_message:
            dc_name = extract_dc_name(log_event_message)
            dc_names[stream] = dc_name

    # Update the secret with the new DC names
    update_secret(dc_names)

    return dc_names