import os
import boto3

def lambda_handler(event, context):
    # Specify your ECS cluster and service details
    cluster_name = os.environ.get('cluster_name')
    service_name = os.environ.get('service_name')

    # Create ECS client
    ecs_client = boto3.client('ecs')

    # Stop ECS service
    try:
        response = ecs_client.update_service(
            cluster = cluster_name,
            service = service_name,
            desiredCount = 0  # Set desiredCount to 0 to stop the service
        )
        print(f"Service {service_name} stopped successfully.")
        return {
            'statusCode': 200,
            'body': f"Service {service_name} stopped successfully."
        }
    except Exception as e:
        print(f"Error stopping service {service_name}: {str(e)}")
        return {
            'statusCode': 500,
            'body': f"Error stopping service {service_name}: {str(e)}"
        }
